# 🧪 TESTING CHECKLIST

Use this to systematically test your extension and find bugs/improvements.

## Basic Functionality Tests

### Installation
- [ ] Extension loads without errors
- [ ] Icon appears in toolbar
- [ ] Popup opens when clicking icon
- [ ] API key field is visible

### API Key Management
- [ ] Can enter API key
- [ ] "Save" button works
- [ ] Success message appears
- [ ] Key persists after closing popup
- [ ] Invalid key format shows error

### Core Feature
- [ ] Can highlight text on webpage
- [ ] Right-click menu shows "Check for Fallacies"
- [ ] Loading indicator appears
- [ ] Analysis results display
- [ ] Popup auto-closes after 15 seconds
- [ ] Can manually close popup

---

## Content Tests

Test on these different types of content:

### News Articles
- [ ] CNN article - Record bias score: _____
- [ ] Fox News article - Record bias score: _____
- [ ] BBC article - Record bias score: _____
- [ ] Reuters article - Record bias score: _____

### Social Media
- [ ] Twitter thread (political)
- [ ] Reddit comment
- [ ] Facebook post
- [ ] LinkedIn post

### Different Text Lengths
- [ ] Single sentence (10-20 words)
- [ ] Short paragraph (50-100 words)
- [ ] Long paragraph (200+ words)
- [ ] Multiple paragraphs

### Different Topics
- [ ] Political content
- [ ] Product review
- [ ] Scientific article
- [ ] Opinion piece
- [ ] Advertisement

---

## Edge Cases

- [ ] Empty text selection
- [ ] Very long text (500+ words)
- [ ] Text with emojis
- [ ] Text with special characters
- [ ] Non-English text
- [ ] Code snippets
- [ ] Math equations

---

## UI/UX Tests

- [ ] Popup is readable on different screen sizes
- [ ] Colors are distinguishable
- [ ] Text is readable
- [ ] Buttons are clickable
- [ ] Popup doesn't block important content
- [ ] Animation is smooth
- [ ] Icons are clear

---

## Fallacy Detection Quality

Test if it correctly identifies:

- [ ] **Ad Hominem**: "You're an idiot, so your argument is wrong"
- [ ] **Strawman**: Misrepresenting opponent's position
- [ ] **False Dichotomy**: "You're either with us or against us"
- [ ] **Slippery Slope**: "If we allow X, soon we'll have Y"
- [ ] **Appeal to Emotion**: Fear-mongering without facts
- [ ] **Hasty Generalization**: "I met one person from X who was rude, so all X are rude"

---

## Performance Tests

- [ ] Works on 10 different websites
- [ ] Response time is acceptable (< 5 seconds)
- [ ] Doesn't slow down browsing
- [ ] Doesn't crash on heavy pages
- [ ] Multiple analyses in quick succession

---

## Issues Found

Record any bugs or problems:

1. _______________________________________________
2. _______________________________________________
3. _______________________________________________
4. _______________________________________________
5. _______________________________________________

---

## Improvement Ideas

What could be better?

1. _______________________________________________
2. _______________________________________________
3. _______________________________________________
4. _______________________________________________
5. _______________________________________________

---

## Best/Worst Finds

**Highest Bias Score Found:** _____ on: _______________

**Most Fallacies Detected:** _____ in: _______________

**Surprisingly Low Bias:** _____ on: _______________

**Funniest Result:** _______________________________________________

---

## User Feedback

Test with 3-5 people and record their reactions:

**Person 1:**
- First impression: _________________________________
- Found it useful? Y/N
- Would use again? Y/N
- Suggestions: _____________________________________

**Person 2:**
- First impression: _________________________________
- Found it useful? Y/N
- Would use again? Y/N
- Suggestions: _____________________________________

**Person 3:**
- First impression: _________________________________
- Found it useful? Y/N
- Would use again? Y/N
- Suggestions: _____________________________________

---

## Next Version Features

Based on testing, what should v1.1 have?

Priority 1 (MUST have):
- _______________________________________________
- _______________________________________________

Priority 2 (SHOULD have):
- _______________________________________________
- _______________________________________________

Priority 3 (NICE to have):
- _______________________________________________
- _______________________________________________

---

**COMPLETE THIS CHECKLIST THEN COME BACK FOR v1.1!**
