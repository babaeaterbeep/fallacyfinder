# ⚡ QUICK START - Get Running in 5 Minutes

## Step 1: Get API Key (2 minutes)
1. Go to: https://console.anthropic.com/
2. Sign up (free - they give you $5 credit)
3. Click "Get API Keys" 
4. Create new key → Copy it

## Step 2: Install Extension (1 minute)
1. Open Chrome
2. Go to: `chrome://extensions/`
3. Turn ON "Developer mode" (top right)
4. Click "Load unpacked"
5. Select the `fallacy-detector` folder

## Step 3: Add Your Key (30 seconds)
1. Click the extension icon (purple circle with !)
2. Paste your API key
3. Click "Save API Key"

## Step 4: TEST IT! (1 minute)
1. Go to any news article or social media
2. Highlight a paragraph
3. Right-click → "Check for Fallacies"
4. Watch the magic happen! ✨

---

## First Test Suggestions:

Try it on:
- Twitter political threads
- Reddit r/politics or r/worldnews comments
- News article comment sections
- Opinion pieces from different sources
- Your own writing!

---

## What You'll See:

- **Bias Score**: 0-10 (0 = neutral, 10 = extremely biased)
- **Detected Fallacies**: With explanations
- **Overall Assessment**: Summary of the analysis

---

## Pro Tips:

- Compare bias scores across news sources on the same topic
- Use it on both sides of an argument
- Check your own writing before posting
- Great for fact-checking family group chats 😅

---

## Need Help?

Check README.md for full documentation

**THIS IS YOUR MVP. NOW GO TEST IT AND BREAK IT.**

Post your results! Screenshot that bias score! 

The goal is to LEARN and ITERATE fast.

---

## Next Steps After Testing:

1. Take screenshots of interesting finds
2. Post on Twitter/LinkedIn with #BiasDetector
3. Get feedback from 10 people
4. List what works / what's broken
5. Iterate for v1.1

**NOW GO. STOP READING. START TESTING.** 🚀
