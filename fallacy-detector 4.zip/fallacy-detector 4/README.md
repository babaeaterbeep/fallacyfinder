# 🎯 Fallacy Detector - Chrome Extension

**Fight misinformation and cognitive bias with AI-powered analysis**

## What It Does

This Chrome extension uses Claude AI to analyze highlighted text on any webpage and detect:

- **Ad Hominem** - Attacking the person instead of the argument
- **Strawman** - Misrepresenting someone's argument
- **False Dichotomy** - Presenting only two options when more exist
- **Slippery Slope** - Claiming one thing will lead to extreme consequences
- **Appeal to Emotion** - Using emotions instead of logic
- **Confirmation Bias** - Only seeing evidence that confirms existing beliefs
- **Hasty Generalization** - Drawing broad conclusions from limited evidence
- **Red Herring** - Distracting from the main point
- **Appeal to Authority** - Citing authority as the only evidence
- **Bandwagon** - "Everyone believes it, so it must be true"

Plus a **Bias Score** (0-10) showing overall bias level.

---

## Installation

### Step 1: Get an Anthropic API Key

1. Go to [console.anthropic.com](https://console.anthropic.com/)
2. Sign up or log in
3. Create a new API key
4. Copy it (starts with `sk-ant-...`)

### Step 2: Load the Extension

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right)
3. Click **Load unpacked**
4. Select the `fallacy-detector` folder
5. The extension icon should appear in your toolbar

### Step 3: Add Your API Key

1. Click the extension icon in your toolbar
2. Paste your API key
3. Click **Save API Key**

---

## How to Use

1. **Highlight any text** on a webpage (news article, social media post, comment, etc.)
2. **Right-click** the highlighted text
3. Select **"Check for Fallacies"** from the menu
4. A popup will appear showing:
   - Bias score
   - Detected fallacies with explanations
   - Overall assessment

The analysis popup auto-closes after 15 seconds, or click "Close" to dismiss it.

---

## Tips for Best Results

- **Use on substantial text** - Works best on paragraphs, not single sentences
- **Try different sources** - Compare bias scores across news sites
- **Check social media** - Great for analyzing heated debates on Twitter/Reddit
- **Analyze your own writing** - Select your draft text to check for biases

---

## Privacy & Security

- Your API key is stored **locally** in Chrome's secure storage
- Text is sent to Anthropic's API for analysis
- No data is stored or tracked by this extension
- Open source - review the code yourself

---

## Cost

This extension uses the Claude API which has costs:
- **~$0.003 per analysis** (about 1/3 of a cent)
- If you analyze 100 pieces of text = ~$0.30
- Set usage limits in your Anthropic console

---

## Troubleshooting

**"Please set your API key" error**
- Make sure you've entered your API key in the extension popup
- Verify it starts with `sk-ant-`

**No context menu appears**
- Try refreshing the webpage
- Make sure you've highlighted text before right-clicking

**Analysis fails**
- Check your API key is valid
- Verify you have credits in your Anthropic account
- Try with shorter text selections

---

## Future Improvements

Ideas for v2.0:
- Keyboard shortcut (Ctrl+Shift+F)
- Save analysis history
- Compare bias across multiple sources
- Export reports
- Custom fallacy detection rules
- Browser-native ML model (no API needed)

---

## About

Built to combat misinformation and help people think more critically.

Created with Claude AI by someone who's tired of BS.

**License:** MIT
**Feedback:** Open an issue or submit a PR!

---

## Version

**v1.0** - Initial release
- Context menu integration
- 10 fallacy types
- Bias scoring
- Clean, modern UI
