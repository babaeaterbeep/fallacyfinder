# Welcome to Fallacy Detector Beta! 🧠

Thank you for helping test the **Fallacy Detector** Chrome extension!

## What is it?

Fallacy Detector uses Claude AI to analyze news articles for:
- 15 types of cognitive biases
- Logical fallacies
- Bias score (0-10 scale)
- Specific examples with explanations

**Goal:** Help people identify misinformation and biased reporting.

---

## 🚀 Installation (5 minutes)

### Step 1: Download
Download the extension: [fallacy-detector-v1.4-FINAL.zip]

### Step 2: Unzip
Extract to a folder you'll remember (e.g., Downloads/fallacy-detector)

### Step 3: Prepare Files
In the folder, rename these two files:
- `popup-v1.4.html` → `popup.html`
- `popup-v1.4.js` → `popup.js`

### Step 4: Install in Chrome
1. Open Chrome
2. Go to `chrome://extensions/`
3. Enable "Developer mode" (top right toggle)
4. Click "Load unpacked"
5. Select the `fallacy-detector` folder
6. You should see the pixel brain icon! 🧠

### Step 5: Get API Key
1. Go to https://console.anthropic.com/
2. Sign up or log in
3. Go to "API Keys"
4. Create a new key
5. Copy it (starts with `sk-ant-...`)

### Step 6: Configure Extension
1. Click the pixel brain icon 🧠 in Chrome toolbar
2. Paste your API key
3. Click "Save API Key"
4. Done!

---

## 🎯 How to Use

### Basic Usage:
1. Go to any news website
2. **Important:** Highlight ONLY the main article text
   - Avoid menus, ads, comments, sidebars
   - Just the article content
3. Right-click → "Check for Fallacies"
4. Wait ~6 seconds
5. See results!

### If You Want More Accuracy:
- In the results popup, click "🎯 Run Accurate Check"
- Takes ~17 seconds, gives averaged result from 3 analyses

---

## 🧪 Testing Checklist

Please test these scenarios and report your experience:

### Basic Functionality:
- [ ] Extension installs successfully
- [ ] API key saves without error
- [ ] Right-click menu appears ("Check for Fallacies")
- [ ] Analysis completes and shows results
- [ ] Results make sense

### Different Content Types:
- [ ] Mainstream news (CNN, BBC, NYT)
- [ ] Opinion pieces
- [ ] Political articles (left and right leaning)
- [ ] Scientific articles
- [ ] Local news
- [ ] Social media posts (if applicable)

### Features:
- [ ] Fast mode works (~6 seconds)
- [ ] "Run Accurate" button works
- [ ] Variance warning appears in Fast mode
- [ ] Bias configuration modal opens
- [ ] Select/deselect biases works
- [ ] Download analysis works
- [ ] Re-run analysis works

### Edge Cases:
- [ ] Very short text (1 paragraph)
- [ ] Very long text (full article)
- [ ] Text with lots of quotes
- [ ] Text with ads/navigation mixed in
- [ ] Multiple analyses on same page
- [ ] Switching between tabs

---

## 📊 What to Test

### Suggested Test Sites:

**Neutral/Quality:**
- Associated Press (apnews.com)
- Reuters (reuters.com)
- BBC News (bbc.com/news)
- NPR (npr.org)

**Opinion/Analysis:**
- The Atlantic (theatlantic.com)
- The Guardian Opinion
- National Review
- Jacobin Magazine

**Mixed Bias:**
- Fox News
- MSNBC
- Breitbart (expect high scores)
- InfoWars (expect very high scores)

**Test at least 5-10 articles total**

---

## 💰 Cost Information

**You'll need to pay for API usage:**
- Fast mode: ~$0.006 per analysis
- Accurate mode: ~$0.018 per analysis

**For 50 test analyses:**
- All Fast: ~$0.30
- Mixed: ~$0.40-0.50
- All Accurate: ~$0.90

**Anthropic gives $5 free credit to new accounts**, so testing should be free or very cheap!

---

## 🐛 What to Report

### Bugs:
- Extension crashes
- API errors
- UI glitches
- Incorrect scores (with examples)
- Performance issues

### UX Issues:
- Confusing interface
- Unclear instructions
- Button placement
- Unexpected behavior

### Feature Requests:
- What's missing?
- What would make it better?
- Integration ideas

### Success Stories:
- Did it catch real bias?
- Surprising findings?
- Useful insights?

---

## 📝 Feedback Form

**Please fill out after testing:**
[Google Form Link Here]

**Or email:**
[your-email@example.com]

---

## 🎯 Focus Questions

1. **Accuracy:** Did the bias scores seem accurate?
2. **Speed:** Was 6 seconds acceptable for Fast mode?
3. **UX:** Was the interface intuitive?
4. **Trust:** Do you trust the results?
5. **Value:** Would you use this regularly?
6. **Sharing:** Would you recommend to others?

---

## 💡 Tips for Best Results

1. **Select clean text:** Avoid headers, footers, ads
2. **Full paragraphs:** Not just headlines
3. **Main content:** The article body, not sidebars
4. **Fresh pages:** Reload before analyzing
5. **One at a time:** Don't spam multiple analyses

---

## ⚠️ Known Limitations

- Works best on article text (not comments or social media)
- Requires Anthropic API key ($)
- Fast mode can vary ±2 points
- May struggle with very short text (<50 words)
- Distinguishes article bias from quoted sources

---

## 🤝 Thank You!

Your feedback will help make this tool better for everyone.

**Testing period:** [X days]
**Deadline for feedback:** [Date]

Questions? Contact: [your-contact]

---

## 📚 Additional Resources

- [Full Documentation](link)
- [GitHub Repository](link)
- [Technical Details](link)

---

**Happy testing!** 🧠✨

---

**Version:** 1.4-FINAL
**Release Date:** October 2025
**Powered by:** Claude Sonnet 4
