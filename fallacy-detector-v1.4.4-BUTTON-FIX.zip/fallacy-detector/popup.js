// Available cognitive biases with descriptions
const AVAILABLE_BIASES = [
  { id: 'ad_hominem', name: 'Ad Hominem', description: 'Attacking the person, not the argument' },
  { id: 'strawman', name: 'Strawman', description: 'Misrepresenting the argument' },
  { id: 'false_dichotomy', name: 'False Dichotomy', description: 'Only two options when more exist' },
  { id: 'slippery_slope', name: 'Slippery Slope', description: 'One thing will lead to extreme consequences' },
  { id: 'appeal_to_emotion', name: 'Appeal to Emotion', description: 'Using emotions instead of logic' },
  { id: 'confirmation_bias', name: 'Confirmation Bias', description: 'Only seeing evidence that confirms beliefs' },
  { id: 'hasty_generalization', name: 'Hasty Generalization', description: 'Broad conclusion from limited evidence' },
  { id: 'red_herring', name: 'Red Herring', description: 'Distracting from the main point' },
  { id: 'appeal_to_authority', name: 'Appeal to Authority', description: 'Citing authority as sole evidence' },
  { id: 'bandwagon', name: 'Bandwagon', description: 'Everyone believes it, so it must be true' },
  { id: 'cherry_picking', name: 'Cherry Picking', description: 'Selective use of data/quotes to support one view' },
  { id: 'false_cause', name: 'False Cause', description: 'Assuming correlation equals causation' },
  { id: 'loaded_language', name: 'Loaded Language', description: 'Emotionally charged words by author' },
  { id: 'whataboutism', name: 'Whataboutism', description: 'Deflecting criticism by pointing to other issues' },
  { id: 'anecdotal_evidence', name: 'Anecdotal Evidence', description: 'Using personal stories as primary proof' }
];

// Load saved settings on popup open
document.addEventListener('DOMContentLoaded', async () => {
  const { apiKey } = await chrome.storage.sync.get(['apiKey']);
  if (apiKey) {
    document.getElementById('apiKey').value = apiKey;
  }
  
  const settings = await chrome.storage.sync.get({
    analysisMode: 'fast',
    customRuns: 5,
    selectedBiases: AVAILABLE_BIASES.map(b => b.id)
  });
  
  document.getElementById('analysisMode').value = settings.analysisMode;
  document.getElementById('customRuns').value = settings.customRuns;
  toggleCustomRuns(settings.analysisMode);
  updateBiasCount(settings.selectedBiases.length);
  populateBiasList(settings.selectedBiases);
});

function toggleCustomRuns(mode) {
  document.getElementById('customRunsGroup').style.display = mode === 'custom' ? 'block' : 'none';
}

function updateBiasCount(count) {
  document.getElementById('biasCount').textContent = count;
}

function populateBiasList(selectedBiases) {
  const biasList = document.getElementById('biasList');
  biasList.innerHTML = '';
  AVAILABLE_BIASES.forEach(bias => {
    const isChecked = selectedBiases.includes(bias.id);
    const item = document.createElement('div');
    item.className = 'bias-item';
    item.innerHTML = `
      <input type="checkbox" id="bias_${bias.id}" ${isChecked ? 'checked' : ''}>
      <div class="bias-item-content">
        <div class="bias-item-name">${bias.name}</div>
        <div class="bias-item-description">${bias.description}</div>
      </div>
    `;
    item.addEventListener('click', (e) => {
      if (e.target.tagName !== 'INPUT') {
        item.querySelector('input').checked = !item.querySelector('input').checked;
      }
    });
    biasList.appendChild(item);
  });
}

document.getElementById('analysisMode').addEventListener('change', (e) => {
  toggleCustomRuns(e.target.value);
});

document.getElementById('saveBtn').addEventListener('click', async () => {
  const apiKey = document.getElementById('apiKey').value.trim();
  const statusDiv = document.getElementById('status');
  const saveBtn = document.getElementById('saveBtn');
  if (!apiKey) {
    showStatus(statusDiv, 'Please enter an API key', 'error');
    return;
  }
  if (!apiKey.startsWith('sk-ant-')) {
    showStatus(statusDiv, 'Invalid API key format. Should start with sk-ant-', 'error');
    return;
  }
  saveBtn.disabled = true;
  saveBtn.textContent = 'Saving...';
  try {
    await chrome.storage.sync.set({ apiKey });
    showStatus(statusDiv, '✓ API key saved successfully!', 'success');
    saveBtn.textContent = 'Saved!';
    setTimeout(() => {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save API Key';
    }, 2000);
  } catch (error) {
    showStatus(statusDiv, 'Error saving API key: ' + error.message, 'error');
    saveBtn.disabled = false;
    saveBtn.textContent = 'Save API Key';
  }
});

document.getElementById('saveSettingsBtn').addEventListener('click', async () => {
  const statusDiv = document.getElementById('settingsStatus');
  const analysisMode = document.getElementById('analysisMode').value;
  const customRuns = parseInt(document.getElementById('customRuns').value);
  if (analysisMode === 'custom' && (customRuns < 1 || customRuns > 100)) {
    showStatus(statusDiv, 'Custom runs must be between 1 and 100', 'error');
    return;
  }
  try {
    const currentSettings = await chrome.storage.sync.get(['selectedBiases']);
    await chrome.storage.sync.set({
      analysisMode,
      customRuns,
      selectedBiases: currentSettings.selectedBiases || AVAILABLE_BIASES.map(b => b.id)
    });
    showStatus(statusDiv, '✓ Settings saved!', 'success');
  } catch (error) {
    showStatus(statusDiv, 'Error saving settings: ' + error.message, 'error');
  }
});

document.getElementById('configureBiasesBtn').addEventListener('click', () => {
  document.getElementById('biasModal').style.display = 'flex';
});

document.getElementById('closeBiasModal').addEventListener('click', () => {
  document.getElementById('biasModal').style.display = 'none';
});

document.getElementById('biasModal').addEventListener('click', (e) => {
  if (e.target.id === 'biasModal') {
    document.getElementById('biasModal').style.display = 'none';
  }
});

document.getElementById('selectAllBiases').addEventListener('click', () => {
  document.querySelectorAll('.bias-item input[type="checkbox"]').forEach(cb => cb.checked = true);
});

document.getElementById('deselectAllBiases').addEventListener('click', () => {
  document.querySelectorAll('.bias-item input[type="checkbox"]').forEach(cb => cb.checked = false);
});

document.getElementById('saveBiasesBtn').addEventListener('click', async () => {
  const selectedBiases = [];
  AVAILABLE_BIASES.forEach(bias => {
    const checkbox = document.getElementById(`bias_${bias.id}`);
    if (checkbox && checkbox.checked) selectedBiases.push(bias.id);
  });
  if (selectedBiases.length === 0) {
    alert('Please select at least one cognitive bias to detect.');
    return;
  }
  try {
    const currentSettings = await chrome.storage.sync.get(['analysisMode', 'customRuns']);
    await chrome.storage.sync.set({ ...currentSettings, selectedBiases });
    updateBiasCount(selectedBiases.length);
    document.getElementById('biasModal').style.display = 'none';
    showStatus(document.getElementById('settingsStatus'), `✓ ${selectedBiases.length} biases selected!`, 'success');
  } catch (error) {
    alert('Error saving bias selection: ' + error.message);
  }
});

function showStatus(statusDiv, message, type) {
  statusDiv.textContent = message;
  statusDiv.className = 'status ' + type;
  if (type === 'success') {
    setTimeout(() => statusDiv.style.display = 'none', 3000);
  }
}
