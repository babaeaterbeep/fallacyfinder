# ✅ Quick Test - Verify All Features Work

## Test 1: Fast Mode (Default)
**Time: 30 seconds**

1. Go to any news site
2. Highlight a paragraph
3. Right-click → "Check for Fallacies"
4. ⏱️ Should take ~6 seconds
5. ✅ Look for yellow warning box: "⚠️ Fast mode may vary ±2 points"
6. ✅ Look for blue button: "🎯 Run Accurate Check"
7. ✅ See: "Fast mode (single analysis)"

**Expected:**
- Fast analysis (6 sec)
- Variance warning shown
- Run Accurate button present
- NO individual scores (only 1 run)

---

## Test 2: Run Accurate Button
**Time: 1 minute**

1. From Fast mode results above
2. Click "🎯 Run Accurate Check" button
3. ⏱️ Should take ~17 seconds
4. ✅ Yellow warning should be GONE
5. ✅ Blue "Run Accurate" button should be GONE
6. ✅ See: "Individual scores: [x, x, x]"
7. ✅ See: "Based on 3 analyses (accurate mode)"

**Expected:**
- 3-run analysis (17 sec)
- NO variance warning
- NO Run Accurate button
- Individual scores shown

---

## Test 3: Fast → Accurate Consistency
**Time: 2 minutes**

Test on same article:

**Fast:**
1. Analyze article (Fast mode)
2. Note the score: ___/10

**Accurate:**
1. Click "Run Accurate"
2. Note the averaged score: ___/10

**Expected:**
- Scores should be similar (within ±2 points)
- If very different, that's why Accurate mode exists!

---

## Test 4: Re-run Same Mode
**Time: 30 seconds**

1. From Accurate results
2. Click "🔄 Re-run Analysis"
3. Should run Accurate again (3 runs)
4. Score should be nearly identical (±0.5 points)

**Expected:**
- Consistent results on re-run
- Proves multi-run averaging works

---

## Test 5: Extreme Bias Test
**Time: 1 minute**

Go to obviously biased site (e.g., InfoWars):

1. Fast mode analysis
2. Note score: ___/10 (should be 7-10)
3. Click "Run Accurate"
4. Note score: ___/10

**Expected:**
- Fast and Accurate should match
- Extreme bias is obvious in 1 run
- Proves Fast is good enough for extremes

---

## Test 6: Moderate Bias Test
**Time: 1 minute**

Go to mainstream news (NBC, Guardian):

1. Fast mode analysis
2. Note score: ___/10
3. Click "Run Accurate"
4. Note score: ___/10

**Expected:**
- Scores might differ by 1-2 points
- Shows why Accurate is better for moderate bias
- Variance warning was useful!

---

## Test 7: Settings Panel
**Time: 1 minute**

1. Click extension icon
2. Check "Analysis Settings" section exists
3. Check default mode is "Fast"
4. Change to "Accurate"
5. Save settings
6. Analyze text → should take ~17 sec
7. Change back to "Fast"

**Expected:**
- Settings persist
- Mode changes take effect
- No bugs

---

## Test 8: Bias Configuration
**Time: 1 minute**

1. Click "Configure Biases"
2. Modal opens
3. Click "Deselect All"
4. Check only 3 biases
5. Save selection
6. Count shows "(3 selected)"
7. Analyze text
8. Should only check those 3 biases

**Expected:**
- Modal works smoothly
- Bias selection persists
- Analysis respects selection

---

## 🎯 Success Criteria

**All features work if:**
- ✅ Fast mode takes ~6 seconds
- ✅ Accurate mode takes ~17 seconds
- ✅ Yellow warning shows in Fast
- ✅ Blue "Run Accurate" button works
- ✅ Variance is low in Accurate mode
- ✅ Settings persist across uses
- ✅ Bias configuration works

---

## 🐛 If Something's Broken

**Report these details:**
1. Which test failed?
2. What happened?
3. What did you expect?
4. Any console errors? (F12 → Console)
5. Screenshot if possible

---

## ⏱️ Total Test Time: ~10 minutes

**After testing, you'll know:**
- Fast mode works (6 sec)
- Run Accurate works (upgrade)
- Variance warning accurate
- Consistency is good
- Settings work
- Ready for daily use!

---

## 📊 Your Test Results

**Fill this out:**

Test 1 (Fast): ___/10 (time: ___ sec)
Test 2 (Accurate): ___/10 (time: ___ sec, scores: ___, ___, ___)
Test 3 (Consistency): Fast ___ vs Accurate ___ (diff: ___ points)
Test 4 (Re-run): First ___ vs Re-run ___ (diff: ___ points)
Test 5 (Extreme): Fast ___ vs Accurate ___ (InfoWars/similar)
Test 6 (Moderate): Fast ___ vs Accurate ___ (NBC/Guardian)
Test 7 (Settings): ✅ / ❌
Test 8 (Biases): ✅ / ❌

**Overall:** ✅ All working / ⚠️ Some issues / ❌ Broken

---

**Ready to test!** 🚀
