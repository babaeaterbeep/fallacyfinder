# GitHub & Launch Strategy

## 📦 Phase 3: GitHub Setup

### Step-by-Step GitHub Repository Creation

---

## 1. Create Repository

### On GitHub.com:

1. Go to github.com (sign in or create account)
2. Click **"New repository"** (green button)
3. Fill in details:

```
Repository name: fallacy-detector
Description: AI-powered Chrome extension to detect cognitive biases and logical fallacies in news articles
Public ✓ (for open source)
Initialize with:
  [✓] Add a README file
  [✓] Add .gitignore (choose: Node)
  [✓] Choose a license (MIT recommended)
```

4. Click **"Create repository"**

---

## 2. Prepare Your Files

### A. Create README.md (Home Page)

```markdown
# 🧠 Fallacy Detector

AI-powered Chrome extension to detect cognitive biases and logical fallacies in news articles.

![Fallacy Detector Icon](icon128.png)

## ✨ Features

- **15 Cognitive Biases Detected**
- **Fast Mode** (6 seconds) & **Accurate Mode** (17 seconds)
- **Multi-run averaging** for consistent results
- **Customizable bias selection**
- **Modern, intuitive UI**
- **Privacy-focused** (no data stored)

## 🚀 Quick Start

### Installation

1. Download the [latest release](link)
2. Extract ZIP file
3. Rename files:
   - `popup-v1.4.html` → `popup.html`
   - `popup-v1.4.js` → `popup.js`
4. Open Chrome → `chrome://extensions/`
5. Enable "Developer mode"
6. Click "Load unpacked"
7. Select the `fallacy-detector` folder

### Get API Key

1. Go to [console.anthropic.com](https://console.anthropic.com/)
2. Create account (get $5 free credit)
3. Generate API key
4. Paste in extension settings

### Usage

1. Go to any news website
2. Highlight article text (avoid ads/menus)
3. Right-click → "Check for Fallacies"
4. View results in ~6 seconds!

## 📊 How It Works

Uses Claude Sonnet 4 to analyze text for:

- Ad Hominem
- Strawman Arguments
- False Dichotomy
- Appeal to Emotion
- Confirmation Bias
- Cherry Picking
- And 9 more...

Returns:
- Bias score (0-10)
- Specific fallacies with examples
- Confidence scores
- Actionable insights

## 💰 Cost

- Fast mode: ~$0.006 per analysis
- Accurate mode: ~$0.018 per analysis
- 100 analyses/month: $0.60-$1.80

New Anthropic accounts get $5 free credit!

## 🎯 Use Cases

- **Journalists** - Fact-check sources
- **Researchers** - Analyze media bias
- **Students** - Learn critical thinking
- **News readers** - Make informed decisions
- **Educators** - Teach media literacy

## 📚 Documentation

- [Installation Guide](docs/INSTALLATION.md)
- [User Guide](docs/USER_GUIDE.md)
- [Development Writeup](DEVELOPMENT_WRITEUP.md)
- [Technical Details](docs/TECHNICAL.md)
- [FAQ](docs/FAQ.md)

## 🧪 Beta Testing

We're in beta! Help us improve:
- [Feedback Form](link)
- [Report Issues](link)
- [Feature Requests](link)

## 🤝 Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md)

**Ways to contribute:**
- Report bugs
- Suggest features  
- Improve documentation
- Submit pull requests
- Share with others

## 📜 License

MIT License - See [LICENSE](LICENSE)

## 🙏 Acknowledgments

- Built with [Claude Sonnet 4](https://anthropic.com)
- Inspired by media literacy movement
- Thanks to all beta testers!

## 📞 Contact

- **Issues:** GitHub Issues
- **Feedback:** [feedback form]
- **Discussion:** [Discord/Reddit]
- **Email:** [your-email]

## ⭐ Support

If you find this useful:
- ⭐ Star this repo
- 🐛 Report bugs
- 💡 Suggest features
- 📢 Share with others
- 🤝 Contribute code

---

**Fight misinformation with AI-powered critical thinking.** 🧠✨

**Version:** 1.4
**Status:** Beta
**Last Updated:** October 2025
```

---

### B. Create .gitignore

```
# API Keys and sensitive data
*.key
*.pem
.env
config.local.js

# OS files
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
*.swo

# Temporary files
*.log
*.tmp
temp/
tmp/

# Distribution
*.zip
dist/
build/

# Node (if you add build process later)
node_modules/
package-lock.json
```

---

### C. Create LICENSE (MIT)

```
MIT License

Copyright (c) 2025 [Your Name]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

### D. Organize Folder Structure

```
fallacy-detector/
├── README.md
├── LICENSE
├── .gitignore
├── CONTRIBUTING.md
├── CHANGELOG.md
├── manifest.json
├── background.js
├── content.js
├── popup.html
├── popup.js
├── icon16.png
├── icon48.png
├── icon128.png
├── docs/
│   ├── INSTALLATION.md
│   ├── USER_GUIDE.md
│   ├── TECHNICAL.md
│   ├── FAQ.md
│   └── DEVELOPMENT_WRITEUP.md
├── examples/
│   └── screenshots/
│       ├── extension-popup.png
│       ├── analysis-results.png
│       └── settings.png
└── v1.4/
    ├── popup-v1.4.html
    └── popup-v1.4.js
```

---

## 3. Upload to GitHub

### Option A: Via Web (Easiest)

1. Go to your new repository
2. Click **"Add file" → "Upload files"**
3. Drag and drop all files
4. Commit message: "Initial release v1.4"
5. Click **"Commit changes"**

### Option B: Via Command Line

```bash
# Navigate to your fallacy-detector folder
cd /path/to/fallacy-detector

# Initialize git
git init

# Add remote
git remote add origin https://github.com/yourusername/fallacy-detector.git

# Add all files
git add .

# Commit
git commit -m "Initial release v1.4 - Beta launch"

# Push
git branch -M main
git push -u origin main
```

---

## 4. Create a Release

1. On GitHub, go to **"Releases"**
2. Click **"Create a new release"**
3. Fill in:

```
Tag: v1.4.0-beta
Title: Fallacy Detector v1.4 Beta
Description:

# 🧠 Fallacy Detector v1.4 Beta

First public beta release!

## ✨ Features

- AI-powered bias detection (15 types)
- Fast mode (6s) & Accurate mode (17s)
- Multi-run consistency (90% improvement)
- Modern card-based UI
- Pixel brain icon 🧠
- Customizable bias selection

## 📦 Installation

Download `fallacy-detector-v1.4.zip` below, then:

1. Extract ZIP
2. Rename popup-v1.4.html → popup.html
3. Rename popup-v1.4.js → popup.js
4. Load in Chrome (see README)

## 🧪 Beta Testing

This is a beta! Please:
- Test on various news sites
- Report bugs
- Share feedback: [form link]

## 💰 Cost

Requires Anthropic API key:
- $5 free credit for new accounts
- ~$0.006 per Fast analysis
- ~$0.018 per Accurate analysis

## 📚 Docs

- [README](link)
- [Installation Guide](link)
- [User Guide](link)
- [Development Story](link)

## 🙏 Thanks

Thanks to all early testers and feedback providers!

---

**Full Changelog:** [link]
```

4. Upload `fallacy-detector-v1.4-FINAL.zip` as release asset
5. Check **"This is a pre-release"**
6. Click **"Publish release"**

---

## 5. Create Supporting Docs

### docs/INSTALLATION.md

```markdown
# Installation Guide

## Prerequisites

- Google Chrome browser
- Anthropic API account
- 5 minutes

## Step 1: Download

Download the latest release: [link]

## Step 2: Extract

Unzip to a permanent location (not Downloads!)

## Step 3: Prepare Files

Rename two files:
- `popup-v1.4.html` → `popup.html`
- `popup-v1.4.js` → `popup.js`

## Step 4: Load in Chrome

1. Open `chrome://extensions/`
2. Enable "Developer mode" (top right)
3. Click "Load unpacked"
4. Select the `fallacy-detector` folder

You should see the pixel brain icon! 🧠

## Step 5: Get API Key

1. Visit console.anthropic.com
2. Sign up (get $5 free credit)
3. Go to "API Keys"
4. Click "Create Key"
5. Copy the key (starts with `sk-ant-`)

## Step 6: Configure

1. Click the pixel brain icon
2. Paste API key
3. Click "Save API Key"
4. Done!

## Troubleshooting

[See FAQ.md]
```

### docs/FAQ.md

```markdown
# Frequently Asked Questions

## General

**Q: What does this do?**
A: Analyzes news articles for cognitive biases and fallacies using AI.

**Q: Is it free?**
A: Extension is free. API usage costs ~$0.006-$0.018 per analysis.

**Q: How accurate is it?**
A: 85% confidence on average. Better with Accurate mode.

## Installation

**Q: I can't install it**
A: Make sure you renamed the popup-v1.4.* files and enabled Developer mode.

**Q: Where do I get an API key?**
A: console.anthropic.com - new accounts get $5 free credit.

## Usage

**Q: What should I select?**
A: Only the main article text. Avoid menus, ads, comments.

**Q: How long does it take?**
A: Fast mode: ~6 seconds. Accurate mode: ~17 seconds.

**Q: Can I analyze social media posts?**
A: Works best on article-length text. May work on long posts.

## Privacy & Security

**Q: Is my data stored?**
A: No. Text is sent to Anthropic API then discarded.

**Q: Is my API key safe?**
A: Stored locally in Chrome. Never transmitted except to Anthropic.

**Q: Can others see my analyses?**
A: No. Everything is local to your browser.

## Cost

**Q: How much does it cost?**
A: Fast: $0.006 per analysis. Accurate: $0.018. ~$0.50-$1/month typical.

**Q: Can I track usage?**
A: Check your Anthropic console for API usage statistics.

## Troubleshooting

**Q: "API key invalid" error**
A: Check key starts with `sk-ant-` and has no spaces.

**Q: Extension crashes**
A: Reload extension at chrome://extensions/

**Q: Results don't make sense**
A: Make sure you selected only article text, not ads/menus.

[More FAQs...]
```

---

## 📣 Phase 4: Promotion & Distribution

### Week 1: Soft Launch

**Day 1-2: Private Beta**
- Friends & family (5-10 people)
- Collect initial feedback
- Fix critical bugs

**Day 3-4: Invite-Only Beta**
- Share on personal social media
- Invite 20-30 people
- Gather detailed feedback

**Day 5-7: Limited Public Beta**
- Post on:
  - r/chrome_extensions
  - r/MediaAnalysis
  - Personal blog/Medium
- Collect feedback form responses
- Monitor for issues

---

### Week 2: Public Beta Launch

**Monday: Preparation**
- [ ] Final bug fixes from Week 1
- [ ] Update GitHub readme with feedback
- [ ] Prepare assets (screenshots, GIFs)
- [ ] Write launch posts

**Tuesday: Technical Communities**
- [ ] Hacker News: "Show HN: Fallacy Detector - AI-powered bias detection"
- [ ] Reddit r/programming
- [ ] Reddit r/MachineLearning
- [ ] Dev.to blog post

**Wednesday: Product Communities**
- [ ] Product Hunt launch
- [ ] Indie Hackers
- [ ] Reddit r/SideProject

**Thursday: News/Media**
- [ ] Reddit r/news
- [ ] Reddit r/media_criticism
- [ ] Tech Twitter
- [ ] LinkedIn post

**Friday-Sunday: Community Engagement**
- [ ] Respond to all comments
- [ ] Share user testimonials
- [ ] Post updates
- [ ] Thank contributors

---

### Week 3-4: Growth & Iteration

**Ongoing:**
- [ ] Chrome Web Store submission
- [ ] Anthropic Discord showcase
- [ ] Newsletter mentions
- [ ] YouTube demo video
- [ ] Blog partnerships

---

## 🎯 Launch Assets Needed

### 1. Screenshots

Take screenshots of:
- Extension icon in toolbar
- Popup settings interface
- Analysis in progress
- Results display
- Fast mode warning
- Accurate mode with scores
- Bias configuration modal

### 2. Demo GIF

Record 30-second GIF showing:
1. User highlights text
2. Right-click → Check for Fallacies
3. Results appear
4. Click "Run Accurate"
5. Updated results

Tools: LICEcap, ScreenToGif, Kap

### 3. Social Media Graphics

Create:
- Twitter card (1200x628)
- LinkedIn post image
- Product Hunt thumbnail
- Reddit header

### 4. Pitch Variations

**One-liner:**
"AI-powered browser extension to detect bias in news articles"

**Tweet (280 chars):**
"Built an AI-powered Chrome extension that analyzes news articles for cognitive biases & fallacies. 15 bias types, 6-second analysis, 90% consistency improvement. Uses Claude Sonnet 4. Beta now open! 🧠✨ [link]"

**HN Title:**
"Show HN: Fallacy Detector – AI-powered bias detection for news articles"

**Reddit Title:**
"[Project] I built a Chrome extension that uses AI to detect cognitive biases in news articles (with source code)"

**Product Hunt:**
"Detect cognitive biases in news articles with AI. Fast, accurate, privacy-focused."

---

## 📊 Success Metrics

Track:

**Engagement:**
- GitHub stars
- Downloads
- Active users
- Analyses run

**Feedback:**
- Form responses
- Issue reports
- Feature requests
- Testimonials

**Community:**
- Reddit upvotes/comments
- HN points/comments
- Twitter engagement
- Discord joins

**Goals:**
- Week 1: 50 beta users
- Week 2: 200 users
- Week 4: 500 users
- Month 2: 1,000 users

---

## 🎁 Incentives for Beta Testers

**Offer:**
- Early access
- Credit in README
- Beta tester badge (if you add this)
- Input on roadmap
- Anthropic API credit (if you can)

---

## 🔗 Key Links to Prepare

Before launch, have ready:
- [ ] GitHub repository URL
- [ ] Feedback form URL
- [ ] Installation guide URL
- [ ] Demo video URL
- [ ] Discord/community URL (optional)
- [ ] Email for contact
- [ ] Twitter/social handle

---

## 📝 Communication Channels

**Primary:**
- GitHub Issues (bugs/features)
- Google Form (structured feedback)
- Email (direct contact)

**Community (Optional):**
- Discord server
- Reddit community
- Twitter account
- Newsletter

**For Anthropic:**
- Tag @AnthropicAI on Twitter
- Post in Claude Discord
- Email developer relations
- Mention in API showcase

---

## 🎯 Next Steps Checklist

**Immediate (This week):**
- [ ] Create GitHub repository
- [ ] Upload all files
- [ ] Write README.md
- [ ] Create first release
- [ ] Set up Google Form
- [ ] Invite 5-10 friends to test

**Week 2:**
- [ ] Fix critical bugs
- [ ] Update documentation
- [ ] Create screenshots/GIF
- [ ] Write launch posts
- [ ] Soft launch on Reddit

**Week 3:**
- [ ] Hacker News launch
- [ ] Product Hunt launch
- [ ] Chrome Web Store prep
- [ ] Community engagement

**Week 4:**
- [ ] Analyze feedback
- [ ] Plan v1.5 features
- [ ] Start Chrome Web Store process
- [ ] Write update blog post

---

**You're ready to launch!** 🚀

**Questions? Let's refine the plan together!**
