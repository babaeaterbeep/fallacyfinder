# 🎯 How to Select/Unselect Biases

## YES! You can select which biases to detect.

---

## 📍 Where to Find It

### In v1.3 or v1.4:
1. Open extension popup
2. Find "Analysis Settings" section
3. Look for button that says:
   ```
   Configure Biases (15 selected)
   ```
4. Click that button

---

## 🎨 What Opens

A **modal popup** appears with:

### Header:
```
Configure Cognitive Biases          [×]
```

### Buttons:
```
[Select All]  [Deselect All]
```

### 15 Checkboxes:
```
☑ Ad Hominem
  Attacking the person, not the argument

☑ Strawman
  Misrepresenting the argument

☑ False Dichotomy
  Only two options when more exist

☑ Slippery Slope
  One thing will lead to extreme consequences

☑ Appeal to Emotion
  Using emotions instead of logic

☑ Confirmation Bias
  Only seeing evidence that confirms beliefs

☑ Hasty Generalization
  Broad conclusion from limited evidence

☑ Red Herring
  Distracting from the main point

☑ Appeal to Authority
  Citing authority as sole evidence

☑ Bandwagon
  Everyone believes it, so it must be true

☑ Cherry Picking
  Selective use of data/quotes to support one view

☑ False Cause
  Assuming correlation equals causation

☑ Loaded Language
  Emotionally charged words by author

☑ Whataboutism
  Deflecting criticism by pointing to other issues

☑ Anecdotal Evidence
  Using personal stories as primary proof
```

### Footer:
```
[Save Selection]
```

---

## 🎯 How to Use

### Select Specific Biases:
1. Click "Configure Biases"
2. Click "Deselect All"
3. Check only the ones you want (e.g., just 3-5)
4. Click "Save Selection"
5. Button updates to show: "(5 selected)"

### Select All:
1. Click "Configure Biases"
2. Click "Select All"
3. All 15 checkboxes check
4. Click "Save Selection"

### Deselect All:
1. Click "Configure Biases"
2. Click "Deselect All"
3. All checkboxes uncheck
4. Check at least 1 (required)
5. Click "Save Selection"

---

## 💡 Why Would You Do This?

### Reason 1: Focus on Specific Issues
**Example:** You only care about emotional manipulation
- Select only: Appeal to Emotion, Loaded Language
- Faster analysis (fewer biases to check)
- More focused results

### Reason 2: Testing
**Example:** You want to see if an article uses strawman arguments
- Select only: Strawman
- Quick targeted check
- Clear yes/no answer

### Reason 3: Speed
**Example:** You want super fast analysis
- Select only 3-5 most important biases
- Faster API response
- Slightly lower cost

### Reason 4: Noise Reduction
**Example:** Some biases are less relevant for your use case
- Uncheck ones you don't care about
- Less clutter in results
- Cleaner analysis

---

## 🔧 What Happens After Selection

### Immediate:
- Button updates: "Configure Biases (**5** selected)"
- Setting saved to browser storage
- Status card updates (v1.4 only)

### Next Analysis:
- Claude ONLY checks selected biases
- Faster response (fewer biases = less processing)
- Results show only selected bias types
- Clearer, more focused output

---

## 💰 Cost Impact

**Fewer biases = slightly lower cost:**

**All 15 biases:**
- Prompt size: ~400 tokens
- Cost per analysis: ~$0.006 (Fast) / $0.018 (Accurate)

**Only 5 biases:**
- Prompt size: ~250 tokens
- Cost per analysis: ~$0.004 (Fast) / $0.012 (Accurate)

**Savings:** ~33% on prompt tokens

---

## 🎯 Example Use Cases

### Use Case 1: Political Analysis
**Select:**
- Strawman
- False Dichotomy
- Appeal to Emotion
- Loaded Language
- Whataboutism

**Why:** Most common in political writing

### Use Case 2: Scientific Articles
**Select:**
- Cherry Picking
- Confirmation Bias
- Hasty Generalization
- False Cause
- Anecdotal Evidence

**Why:** Common scientific fallacies

### Use Case 3: Opinion Pieces
**Select:**
- Ad Hominem
- Appeal to Emotion
- Bandwagon
- Loaded Language
- Appeal to Authority

**Why:** Common in opinion writing

### Use Case 4: Marketing/Ads
**Select:**
- Appeal to Emotion
- Bandwagon
- Cherry Picking
- Loaded Language
- Appeal to Authority

**Why:** Common persuasion techniques

---

## 🐛 Troubleshooting

### Problem: Button doesn't open modal
**Solution:**
1. Make sure you're using v1.3 or v1.4-FIXED
2. Check browser console for errors (F12)
3. Reload extension
4. Try again

### Problem: Can't save selection
**Solution:**
1. Must select at least 1 bias
2. Click "Save Selection" button
3. Wait for confirmation
4. Close modal

### Problem: Selection not persisting
**Solution:**
1. Make sure you clicked "Save Selection"
2. Check browser storage permissions
3. Try clearing extension data and re-setting

---

## 🎨 Visual Guide

### v1.3:
```
┌─────────────────────────┐
│ ⚙️ Analysis Settings    │
├─────────────────────────┤
│ Mode: [⚡ Fast ▼]       │
│                         │
│ [Configure Biases       │ ← Click this
│  (15 selected)]         │
│                         │
└─────────────────────────┘

        ↓ Opens modal ↓

┌──────────────────────────┐
│ Configure Cognitive      │
│ Biases               [×] │
├──────────────────────────┤
│ [Select All][Deselect All]│
│                          │
│ ☑ Ad Hominem             │
│   Attacking person...    │
│                          │
│ ☑ Strawman               │
│   Misrepresenting...     │
│                          │
│ ... (15 total)           │
│                          │
├──────────────────────────┤
│ [Save Selection]         │
└──────────────────────────┘
```

### v1.4:
```
┌─────────────────────────┐
│ ⚙️ Analysis Settings    │
│ ─────────────────────── │
│ Mode: [⚡ Fast ▼]       │
│                         │
│ Cognitive Biases        │
│ [15 biases selected ·   │ ← Click this
│  Configure]             │
│                         │
│ [Update Settings]       │
└─────────────────────────┘

        ↓ Opens modal ↓

┌──────────────────────────┐
│ Configure Cognitive      │
│ Biases               [×] │
├──────────────────────────┤
│ [Select All][Deselect All]│
│                          │
│ ☑ Ad Hominem             │
│   Attacking person...    │
│                          │
│ ☑ Strawman               │
│   Misrepresenting...     │
│                          │
│ ... (15 total)           │
│                          │
├──────────────────────────┤
│ [Save Selection]         │
└──────────────────────────┘
```

---

## ✅ Confirmation

After saving:
- Modal closes
- Button updates: "(X selected)" where X = number checked
- Next analysis uses only selected biases
- Status card shows updated count (v1.4)

---

## 🎯 Pro Tips

1. **Start with all 15** - See full analysis first
2. **Narrow down** - Uncheck ones you don't care about
3. **Test focused** - Try single bias for targeted checking
4. **Save presets** - Can't save yet, but good feature idea!

---

## 📦 Fixed in v1.4

**Bug:** Modal HTML was missing in initial v1.4 release
**Fixed:** v1.4-FIXED includes complete modal

**Download:** [v1.4-FIXED.zip](computer:///mnt/user-data/outputs/fallacy-detector-v1.4-FIXED.zip)

---

## 🚀 Try It Now

1. Open extension popup
2. Find "Configure Biases" button
3. Click it
4. Select/unselect biases
5. Save selection
6. Analyze some text
7. See focused results!

---

**The feature definitely exists and should work in all versions!** 

If it's not working, let me know and I'll debug further. 🎯
