# CHANGELOG - v1.1

## What Changed (Combo 1 Implementation)

### ✅ Feature 1: Analysis Stays Open
**OLD:** Popup auto-closed after 15 seconds
**NEW:** Popup stays open until you manually close it

**Why:** Gives you unlimited time to read and understand the analysis

---

### ✅ Feature 2: Download Analysis
**NEW:** Green "Download Analysis" button in popup footer

**What it does:**
- Saves analysis as a formatted text file
- Filename: `fallacy-analysis-[timestamp].txt`
- Includes date/time, original text, bias score, fallacies, and assessment

---

## How to Update

1. Go to your extension folder
2. Replace `content.js` with the new one
3. Go to `chrome://extensions/`
4. Click refresh icon on Fallacy Detector
5. Done!

---

**Version:** 1.1
**Date:** October 13, 2025
**Build time:** 10 minutes
**New features:** 2
