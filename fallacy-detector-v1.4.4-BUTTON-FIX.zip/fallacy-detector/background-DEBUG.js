// DEBUG VERSION - v1.3
console.log("Background script loaded!");

// Create context menu when extension is installed
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed/updated");
  chrome.contextMenus.create({
    id: "checkFallacies",
    title: "Check for Fallacies",
    contexts: ["selection"]
  });
  console.log("Context menu created");
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  console.log("Context menu clicked", info.menuItemId);
  if (info.menuItemId === "checkFallacies") {
    const selectedText = info.selectionText;
    console.log("Selected text:", selectedText.substring(0, 100) + "...");
    analyzeFallacies(selectedText, tab.id);
  }
});

// Handle messages from content script (for re-run)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message received:", message.type);
  if (message.type === 'RERUN_ANALYSIS') {
    analyzeFallacies(message.text, sender.tab.id);
  }
});

// Helper function to make a single API call
async function makeSingleAnalysisCall(apiKey, text, selectedBiases) {
  console.log("Making API call...");
  console.log("Selected biases:", selectedBiases);
  
  // Bias mapping
  const BIAS_DESCRIPTIONS = {
    ad_hominem: 'Ad Hominem (attacking the person, not the argument)',
    strawman: 'Strawman (misrepresenting the argument)',
    false_dichotomy: 'False Dichotomy (only two options when more exist)',
    slippery_slope: 'Slippery Slope (one thing will lead to extreme consequences)',
    appeal_to_emotion: 'Appeal to Emotion (using emotions instead of logic)',
    confirmation_bias: 'Confirmation Bias (only seeing evidence that confirms beliefs)',
    hasty_generalization: 'Hasty Generalization (broad conclusion from limited evidence)',
    red_herring: 'Red Herring (distracting from the main point)',
    appeal_to_authority: 'Appeal to Authority (citing authority as sole evidence)',
    bandwagon: 'Bandwagon (everyone believes it, so it must be true)',
    cherry_picking: 'Cherry Picking (selective use of data/quotes to support one view)',
    false_cause: 'False Cause (assuming correlation equals causation)',
    loaded_language: 'Loaded Language (emotionally charged words by author, not in quotes)',
    whataboutism: 'Whataboutism (deflecting criticism by pointing to other issues)',
    anecdotal_evidence: 'Anecdotal Evidence (using personal stories as primary proof)'
  };
  
  // Use all biases if none selected or selectedBiases is null/undefined
  const biasesToCheck = selectedBiases && selectedBiases.length > 0 
    ? selectedBiases 
    : Object.keys(BIAS_DESCRIPTIONS);
  
  console.log("Biases to check:", biasesToCheck);
  
  // Build bias list for prompt
  const biasListText = biasesToCheck
    .map(id => `- ${BIAS_DESCRIPTIONS[id]}`)
    .join('\n');
  
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      temperature: 0,
      messages: [{
        role: 'user',
        content: `Analyze this text for logical fallacies and cognitive biases. Be specific and concise.

IMPORTANT: If the text appears to be navigation menus, advertisements, comments sections, or other non-article content, note this and focus only on substantive article text. Discount irrelevant page elements from your analysis.

CRITICAL DISTINCTION: Distinguish between the ARTICLE'S bias and QUOTED SOURCES' bias. Good journalism quotes biased people - rate the ARTICLE/AUTHOR's presentation, not the people being quoted.

Detect these fallacies and biases IN THE ARTICLE'S PRESENTATION:
${biasListText}

Text to analyze:
"${text}"

Format your response as JSON:
{
  "fallacies": [
    {
      "type": "Fallacy Name",
      "explanation": "Brief explanation of how this fallacy appears in the ARTICLE (not quoted sources)",
      "severity": "high/medium/low"
    }
  ],
  "overall_assessment": "Brief summary",
  "bias_score": 0-10 (rate the ARTICLE/AUTHOR, not quoted sources. 0=neutral, 10=extremely biased),
  "confidence": 0-100 (how confident are you in this assessment?),
  "text_quality": "article/mixed/non-article" (is this substantive article text or page elements?)
}

If the text is mostly navigation/ads/irrelevant content, set text_quality to "non-article" and note this in overall_assessment.
If the text quotes biased sources but the article itself is balanced, bias_score should be LOW (2-3).

If no fallacies found, return empty fallacies array.`
      }]
    })
  });

  console.log("API response status:", response.status);
  
  const data = await response.json();
  console.log("API response data:", data);
  
  if (data.error) {
    console.error("API error:", data.error);
    throw new Error(data.error.message);
  }

  // Parse Claude's response
  const content = data.content[0].text;
  console.log("Claude response:", content.substring(0, 200));
  
  try {
    // Try to extract JSON from the response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const result = JSON.parse(jsonMatch[0]);
      console.log("Parsed result:", result);
      return result;
    } else {
      console.warn("No JSON found in response, using fallback");
      // Fallback if not JSON formatted
      return {
        fallacies: [],
        overall_assessment: content,
        bias_score: 5,
        confidence: 50
      };
    }
  } catch (e) {
    console.error("Error parsing JSON:", e);
    return {
      fallacies: [],
      overall_assessment: content,
      bias_score: 5,
      confidence: 50
    };
  }
}

// Analyze text for fallacies using Claude API (adjustable runs based on settings)
async function analyzeFallacies(text, tabId) {
  console.log("analyzeFallacies called for tab:", tabId);
  
  try {
    // Get API key and settings from storage
    console.log("Getting settings from storage...");
    const settings = await chrome.storage.sync.get({
      apiKey: null,
      analysisMode: 'accurate',
      customRuns: 5,
      selectedBiases: null
    });
    
    console.log("Settings loaded:", {
      hasApiKey: !!settings.apiKey,
      analysisMode: settings.analysisMode,
      customRuns: settings.customRuns,
      selectedBiases: settings.selectedBiases
    });
    
    if (!settings.apiKey) {
      console.error("No API key found");
      chrome.tabs.sendMessage(tabId, {
        type: 'FALLACY_RESULT',
        error: 'Please set your Anthropic API key in the extension popup first.'
      });
      return;
    }

    // Determine number of runs based on mode
    let numRuns;
    switch (settings.analysisMode) {
      case 'fast':
        numRuns = 1;
        break;
      case 'accurate':
        numRuns = 3;
        break;
      case 'custom':
        numRuns = Math.min(100, Math.max(1, settings.customRuns));
        break;
      default:
        numRuns = 3;
    }
    
    console.log("Number of runs:", numRuns);

    // Show loading state
    console.log("Sending loading message...");
    chrome.tabs.sendMessage(tabId, {
      type: 'FALLACY_LOADING',
      runs: numRuns
    });

    // Run analysis multiple times
    const results = [];
    const biasScores = [];
    
    console.log("Starting analysis loop...");
    for (let i = 0; i < numRuns; i++) {
      console.log(`Run ${i + 1} of ${numRuns}`);
      const result = await makeSingleAnalysisCall(settings.apiKey, text, settings.selectedBiases);
      results.push(result);
      biasScores.push(result.bias_score || 5);
    }
    
    console.log("All runs complete. Bias scores:", biasScores);
    
    // Calculate average bias score
    const avgBiasScore = Math.round((biasScores.reduce((a, b) => a + b, 0) / biasScores.length) * 10) / 10;
    
    // Use the result with the median bias score for fallacies and assessment
    const sortedResults = [...results].sort((a, b) => (a.bias_score || 5) - (b.bias_score || 5));
    const medianResult = sortedResults[Math.floor(sortedResults.length / 2)];
    
    // Combine all unique fallacies from all runs
    const allFallacies = [];
    const fallacyMap = new Map();
    
    results.forEach(result => {
      if (result.fallacies) {
        result.fallacies.forEach(fallacy => {
          const key = fallacy.type;
          if (!fallacyMap.has(key)) {
            fallacyMap.set(key, fallacy);
            allFallacies.push(fallacy);
          }
        });
      }
    });
    
    // Create final result
    const finalResult = {
      fallacies: allFallacies,
      overall_assessment: medianResult.overall_assessment,
      bias_score: avgBiasScore,
      individual_scores: numRuns > 1 ? biasScores : undefined,
      confidence: medianResult.confidence || 80,
      text_quality: medianResult.text_quality || 'article',
      runs: numRuns,
      mode: settings.analysisMode
    };

    console.log("Final result:", finalResult);
    console.log("Sending result to tab...");
    
    // Send result back to content script
    chrome.tabs.sendMessage(tabId, {
      type: 'FALLACY_RESULT',
      data: finalResult,
      originalText: text
    });
    
    console.log("Result sent successfully");

  } catch (error) {
    console.error("Error in analyzeFallacies:", error);
    chrome.tabs.sendMessage(tabId, {
      type: 'FALLACY_RESULT',
      error: error.message
    });
  }
}
