// Create context menu when extension is installed
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "checkFallacies",
    title: "Check for Fallacies",
    contexts: ["selection"]
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "checkFallacies") {
    const selectedText = info.selectionText;
    analyzeFallacies(selectedText, tab.id);
  }
});

// Handle messages from content script (for re-run)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'RERUN_ANALYSIS') {
    analyzeFallacies(message.text, sender.tab.id);
  } else if (message.type === 'RUN_ACCURATE_ANALYSIS') {
    analyzeFallacies(message.text, sender.tab.id, 'accurate');
  }
});

// Helper function to make a single API call
async function makeSingleAnalysisCall(apiKey, text, selectedBiases) {
  // Bias mapping
  const BIAS_DESCRIPTIONS = {
    ad_hominem: 'Ad Hominem (attacking the person, not the argument)',
    strawman: 'Strawman (misrepresenting the argument)',
    false_dichotomy: 'False Dichotomy (only two options when more exist)',
    slippery_slope: 'Slippery Slope (one thing will lead to extreme consequences)',
    appeal_to_emotion: 'Appeal to Emotion (using emotions instead of logic)',
    confirmation_bias: 'Confirmation Bias (only seeing evidence that confirms beliefs)',
    hasty_generalization: 'Hasty Generalization (broad conclusion from limited evidence)',
    red_herring: 'Red Herring (distracting from the main point)',
    appeal_to_authority: 'Appeal to Authority (citing authority as sole evidence)',
    bandwagon: 'Bandwagon (everyone believes it, so it must be true)',
    cherry_picking: 'Cherry Picking (selective use of data/quotes to support one view)',
    false_cause: 'False Cause (assuming correlation equals causation)',
    loaded_language: 'Loaded Language (emotionally charged words by author, not in quotes)',
    whataboutism: 'Whataboutism (deflecting criticism by pointing to other issues)',
    anecdotal_evidence: 'Anecdotal Evidence (using personal stories as primary proof)'
  };
  
  // Use all biases if none selected
  const biasesToCheck = selectedBiases && selectedBiases.length > 0 
    ? selectedBiases 
    : Object.keys(BIAS_DESCRIPTIONS);
  
  // Build bias list for prompt
  const biasListText = biasesToCheck
    .map(id => `- ${BIAS_DESCRIPTIONS[id]}`)
    .join('\n');
  
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1024,
      temperature: 0,
      messages: [{
        role: 'user',
        content: `Analyze this text for logical fallacies and cognitive biases. Be specific and concise.

IMPORTANT: If the text appears to be navigation menus, advertisements, comments sections, or other non-article content, note this and focus only on substantive article text. Discount irrelevant page elements from your analysis.

CRITICAL DISTINCTION: Distinguish between the ARTICLE'S bias and QUOTED SOURCES' bias. Good journalism quotes biased people - rate the ARTICLE/AUTHOR's presentation, not the people being quoted.

ONLY detect these SPECIFIC fallacies and biases IN THE ARTICLE'S PRESENTATION (ignore all others):
${biasListText}

IMPORTANT: Do NOT report any fallacies or biases that are not in the list above. Only check for the specific types listed.

Text to analyze:
"${text}"

Format your response as JSON:
{
  "fallacies": [
    {
      "type": "Fallacy Name",
      "explanation": "Brief explanation of how this fallacy appears in the ARTICLE (not quoted sources)",
      "severity": "high/medium/low"
    }
  ],
  "overall_assessment": "Brief summary",
  "bias_score": 0-10 (rate the ARTICLE/AUTHOR, not quoted sources. 0=neutral, 10=extremely biased),
  "confidence": 0-100 (how confident are you in this assessment?),
  "text_quality": "article/mixed/non-article" (is this substantive article text or page elements?)
}

If the text is mostly navigation/ads/irrelevant content, set text_quality to "non-article" and note this in overall_assessment.
If the text quotes biased sources but the article itself is balanced, bias_score should be LOW (2-3).

If no fallacies from the specified list are found, return empty fallacies array.`
      }]
    })
  });

  const data = await response.json();
  
  if (data.error) {
    throw new Error(data.error.message);
  }

  // Parse Claude's response
  const content = data.content[0].text;
  
  try {
    // Try to extract JSON from the response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    } else {
      // Fallback if not JSON formatted
      return {
        fallacies: [],
        overall_assessment: content,
        bias_score: 5,
        confidence: 50
      };
    }
  } catch (e) {
    return {
      fallacies: [],
      overall_assessment: content,
      bias_score: 5,
      confidence: 50
    };
  }
}

// Analyze text for fallacies using Claude API (adjustable runs based on settings)
async function analyzeFallacies(text, tabId, modeOverride = null) {
  try {
    // Get API key and settings from storage
    const settings = await chrome.storage.sync.get({
      apiKey: null,
      analysisMode: 'fast',
      customRuns: 5,
      selectedBiases: ['ad_hominem', 'strawman', 'false_dichotomy', 'slippery_slope', 'appeal_to_emotion', 'confirmation_bias', 'hasty_generalization', 'red_herring', 'appeal_to_authority', 'bandwagon', 'cherry_picking', 'false_cause', 'loaded_language', 'whataboutism', 'anecdotal_evidence']
    });
    
    if (!settings.apiKey) {
      chrome.tabs.sendMessage(tabId, {
        type: 'FALLACY_RESULT',
        error: 'Please set your Anthropic API key in the extension popup first.'
      });
      return;
    }

    // Use override mode if provided, otherwise use saved setting
    const effectiveMode = modeOverride || settings.analysisMode;

    // Determine number of runs based on mode
    let numRuns;
    switch (effectiveMode) {
      case 'fast':
        numRuns = 1;
        break;
      case 'accurate':
        numRuns = 3;
        break;
      case 'custom':
        numRuns = Math.min(100, Math.max(1, settings.customRuns));
        break;
      default:
        numRuns = 3;
    }

    // Show loading state
    chrome.tabs.sendMessage(tabId, {
      type: 'FALLACY_LOADING',
      runs: numRuns
    });

    // Run analysis multiple times
    const results = [];
    const biasScores = [];
    
    for (let i = 0; i < numRuns; i++) {
      const result = await makeSingleAnalysisCall(settings.apiKey, text, settings.selectedBiases);
      results.push(result);
      biasScores.push(result.bias_score || 5);
    }
    
    // Calculate average bias score
    const avgBiasScore = Math.round((biasScores.reduce((a, b) => a + b, 0) / biasScores.length) * 10) / 10;
    
    // Use the result with the median bias score for fallacies and assessment
    const sortedResults = [...results].sort((a, b) => (a.bias_score || 5) - (b.bias_score || 5));
    const medianResult = sortedResults[Math.floor(sortedResults.length / 2)];
    
    // Combine all unique fallacies from all runs
    const allFallacies = [];
    const fallacyMap = new Map();
    
    results.forEach(result => {
      if (result.fallacies) {
        result.fallacies.forEach(fallacy => {
          const key = fallacy.type;
          if (!fallacyMap.has(key)) {
            fallacyMap.set(key, fallacy);
            allFallacies.push(fallacy);
          }
        });
      }
    });
    
    // Create final result
    const finalResult = {
      fallacies: allFallacies,
      overall_assessment: medianResult.overall_assessment,
      bias_score: avgBiasScore,
      individual_scores: numRuns > 1 ? biasScores : undefined,
      confidence: medianResult.confidence || 80,
      text_quality: medianResult.text_quality || 'article',
      runs: numRuns,
      mode: effectiveMode,
      selectedBiases: settings.selectedBiases
    };

    // Send result back to content script
    chrome.tabs.sendMessage(tabId, {
      type: 'FALLACY_RESULT',
      data: finalResult,
      originalText: text
    });

  } catch (error) {
    chrome.tabs.sendMessage(tabId, {
      type: 'FALLACY_RESULT',
      error: error.message
    });
  }
}
