# 📸 What It Looks Like

## Extension Icon
```
Your Chrome toolbar will show:
┌─────┐
│  !  │  <- Purple circle with white exclamation mark
└─────┘
```

## Settings Popup (When you click the icon)
```
╔═══════════════════════════════════════════╗
║  🎯 Fallacy Detector                      ║
║  Combat misinformation with AI            ║
╠═══════════════════════════════════════════╣
║                                           ║
║  How to use:                              ║
║  1. Add your Anthropic API key below      ║
║  2. Highlight any text on a webpage       ║
║  3. Right-click → "Check for Fallacies"   ║
║  4. View the analysis!                    ║
║                                           ║
║  Anthropic API Key                        ║
║  ┌─────────────────────────────────────┐ ║
║  │ sk-ant-...                          │ ║
║  └─────────────────────────────────────┘ ║
║                                           ║
║  Don't have an API key?                   ║
║  Get one at console.anthropic.com         ║
║                                           ║
║  ┌─────────────────────────────────────┐ ║
║  │      Save API Key                   │ ║
║  └─────────────────────────────────────┘ ║
║                                           ║
║  ✨ What it detects:                      ║
║  • Ad Hominem                             ║
║  • Strawman Arguments                     ║
║  • False Dichotomy                        ║
║  • And 7 more...                          ║
╚═══════════════════════════════════════════╝
```

## Context Menu (When you right-click highlighted text)
```
┌──────────────────────────┐
│ Cut                      │
│ Copy                     │
│ Paste                    │
├──────────────────────────┤
│ ✅ Check for Fallacies   │  <- THIS IS YOUR NEW OPTION
├──────────────────────────┤
│ Search Google for...     │
└──────────────────────────┘
```

## Analysis Result Popup (Appears on the webpage)
```
╔═════════════════════════════════════════════════╗
║  🎯 Fallacy Analysis                         [×]║
╠═════════════════════════════════════════════════╣
║                                                 ║
║  Bias Score: 8/10 ████████░░                    ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━       ║
║                                                 ║
║  🔴 Ad Hominem                                  ║
║  The text attacks the person's character        ║
║  rather than addressing their argument.         ║
║                                                 ║
║  🟡 Appeal to Emotion                           ║
║  Uses fear-based language without providing     ║
║  factual evidence to support the claims.        ║
║                                                 ║
║  🔴 False Dichotomy                             ║
║  Presents only two options when multiple        ║
║  alternatives exist.                            ║
║                                                 ║
║  Assessment:                                    ║
║  This text relies heavily on emotional          ║
║  manipulation and personal attacks rather       ║
║  than logical argumentation. Multiple           ║
║  fallacies detected suggest a highly biased     ║
║  perspective.                                   ║
║                                                 ║
║                              ┌────────┐         ║
║                              │ Close  │         ║
║                              └────────┘         ║
╚═════════════════════════════════════════════════╝
```

## Real-World Example

Imagine you're reading a Twitter thread that says:

> "Anyone who supports this policy is clearly an idiot 
> who hates America. If we let this pass, next thing 
> you know we'll be living in a dictatorship. You're 
> either with us or against us!"

You highlight it, right-click, select "Check for Fallacies"

**Your extension shows:**

```
Bias Score: 9/10 (EXTREMELY BIASED)

🔴 Ad Hominem - Calls opponents "idiots" 
🔴 Slippery Slope - "Next thing we'll be in dictatorship"
🔴 False Dichotomy - "Either with us or against us"

Assessment: This text uses multiple logical fallacies 
to manipulate emotion rather than present a rational 
argument. Highly partisan language detected.
```

---

## Color Coding

**Bias Score:**
- 0-3 (Green) = Low bias, mostly factual
- 4-6 (Yellow) = Moderate bias, some opinion
- 7-10 (Red) = High bias, heavily emotional

**Fallacy Severity:**
- 🟢 Low = Minor issue, may not be intentional
- 🟡 Medium = Notable problem, affects argument
- 🔴 High = Major fallacy, undermines credibility

---

## User Experience Flow

1. **See suspicious text** on any website
   ↓
2. **Highlight it** with your mouse
   ↓
3. **Right-click** → "Check for Fallacies"
   ↓
4. **Wait 2-3 seconds** (loading animation)
   ↓
5. **See results** in beautiful popup
   ↓
6. **Feel smarter** 🧠✨

---

## Best Places to Use This

### News Sites
- CNN, Fox News, MSNBC (compare their bias scores!)
- Opinion sections
- Reader comments

### Social Media
- Twitter/X political threads
- Reddit r/politics debates
- Facebook arguments
- LinkedIn thought leaders

### Marketing/Ads
- Product claims
- Political campaign ads
- Sponsored content
- Influencer posts

### Your Own Writing
- Before posting on social media
- Email drafts
- Blog posts
- Argument with your friend 😅

---

**This is what you built in under 60 minutes.**

**Now go install it and watch it work its magic.** ✨

[View the complete extension](computer:///mnt/user-data/outputs/fallacy-detector)
