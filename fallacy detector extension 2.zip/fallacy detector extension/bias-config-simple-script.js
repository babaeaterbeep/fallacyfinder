const biases = [
  { id: 'ad_hominem', name: 'Ad Hominem', desc: 'Attacking the person rather than their argument' },
  { id: 'strawman', name: 'Strawman', desc: 'Misrepresenting an argument to make it easier to attack' },
  { id: 'false_dichotomy', name: 'False Dichotomy', desc: 'Presenting only two options when more exist' },
  { id: 'slippery_slope', name: 'Slippery Slope', desc: 'Claiming one thing will lead to extreme consequences' },
  { id: 'appeal_to_emotion', name: 'Appeal to Emotion', desc: 'Using emotions instead of logical reasoning' },
  { id: 'confirmation_bias', name: 'Confirmation Bias', desc: 'Only presenting evidence that confirms existing beliefs' },
  { id: 'hasty_generalization', name: 'Hasty Generalization', desc: 'Drawing broad conclusions from limited evidence' },
  { id: 'red_herring', name: 'Red Herring', desc: 'Introducing irrelevant information to distract' },
  { id: 'appeal_to_authority', name: 'Appeal to Authority', desc: 'Citing authority as sole evidence without logic' },
  { id: 'bandwagon', name: 'Bandwagon', desc: 'Arguing something is true because many believe it' },
  { id: 'cherry_picking', name: 'Cherry Picking', desc: 'Selectively using data to support one view' },
  { id: 'false_cause', name: 'False Cause', desc: 'Assuming correlation equals causation' },
  { id: 'loaded_language', name: 'Loaded Language', desc: 'Using emotionally charged words to influence' },
  { id: 'whataboutism', name: 'Whataboutism', desc: 'Deflecting criticism by pointing to other issues' },
  { id: 'anecdotal_evidence', name: 'Anecdotal Evidence', desc: 'Using personal stories as primary proof' }
];

let selected = [];

// Load saved preferences
chrome.storage.sync.get({ selectedBiases: biases.map(b => b.id) }, (result) => {
  selected = result.selectedBiases || biases.map(b => b.id);
  render();
});

function render() {
  const container = document.getElementById('biases');
  container.innerHTML = '';
  
  biases.forEach(bias => {
    const checked = selected.includes(bias.id);
    
    const item = document.createElement('div');
    item.className = 'bias-item' + (checked ? ' checked' : '');
    item.addEventListener('click', () => toggle(bias.id));
    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = checked;
    checkbox.addEventListener('click', (e) => {
      e.stopPropagation();
      toggle(bias.id);
    });
    
    const content = document.createElement('div');
    content.className = 'bias-content';
    
    const name = document.createElement('div');
    name.className = 'bias-name';
    name.textContent = bias.name;
    
    const desc = document.createElement('div');
    desc.className = 'bias-desc';
    desc.textContent = bias.desc;
    
    content.appendChild(name);
    content.appendChild(desc);
    
    item.appendChild(checkbox);
    item.appendChild(content);
    
    container.appendChild(item);
  });
  
  document.getElementById('count').textContent = selected.length;
}

function toggle(id) {
  if (selected.includes(id)) {
    selected = selected.filter(x => x !== id);
    if (selected.length === 0) {
      selected = [id];
      alert('At least one bias must be selected!');
    }
  } else {
    selected.push(id);
  }
  render();
}

function selectAll() {
  selected = biases.map(b => b.id);
  render();
}

function selectNone() {
  selected = [biases[0].id];
  render();
}

function save() {
  chrome.storage.sync.set({ selectedBiases: selected }, () => {
    const btn = document.getElementById('save');
    btn.textContent = '✓ Saved!';
    btn.style.background = '#10b981';
    setTimeout(() => window.close(), 500);
  });
}

// Button event listeners
document.getElementById('selectAll').addEventListener('click', selectAll);
document.getElementById('selectNone').addEventListener('click', selectNone);
document.getElementById('save').addEventListener('click', save);
