// Content script - displays analysis results on the page

let currentAnalysis = null;
let currentText = null;
let currentSelectedBiases = null;

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'ping') {
    // Respond to ping to let background know we're ready
    sendResponse({ ready: true });
  } else if (request.action === 'showAnalysis') {
    currentAnalysis = request.analysis;
    currentText = request.originalText;
    currentSelectedBiases = request.selectedBiases || [];
    showAnalysisModal(request.analysis, request.originalText, request.selectedBiases);
    sendResponse({ success: true });
  } else if (request.action === 'showLoading') {
    showLoadingModal(request.mode || 'fast');
    sendResponse({ success: true });
  } else if (request.action === 'hideLoading') {
    const modal = document.getElementById('fallacy-detector-modal');
    if (modal) modal.remove();
    sendResponse({ success: true });
  }
  return true;
});

// Show loading modal
function showLoadingModal(mode) {
  // Remove any existing modals
  const existing = document.getElementById('fallacy-detector-modal');
  if (existing) existing.remove();

  const estimatedTime = mode === 'accurate' ? '15-20' : '6-10';
  
  const modal = document.createElement('div');
  modal.id = 'fallacy-detector-modal';
  modal.innerHTML = `
    <div class="fallacy-modal-container loading">
      <div class="fallacy-modal-header">
        <h2>🔍 Analyzing Text...</h2>
      </div>
      
      <div class="fallacy-modal-body loading-body">
        <div class="loading-spinner"></div>
        <div class="loading-text">
          <p class="loading-primary">AI is analyzing your text for biases and fallacies</p>
          <p class="loading-secondary">This usually takes ${estimatedTime} seconds</p>
          <div class="loading-mode-badge">${mode === 'accurate' ? '🎯 Detailed Analysis' : '⚡ Fast Analysis'}</div>
        </div>
        <div class="loading-progress">
          <div class="loading-progress-bar"></div>
        </div>
      </div>
    </div>
  `;

  // Add styles
  const style = document.createElement('style');
  style.textContent = `
    #fallacy-detector-modal {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 450px;
      max-height: calc(100vh - 40px);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
      from {
        transform: translateX(500px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }

    .fallacy-modal-container {
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      display: flex;
      flex-direction: column;
      max-height: calc(100vh - 40px);
    }

    .fallacy-modal-container.loading {
      height: auto;
    }

    .fallacy-modal-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px;
      border-radius: 12px 12px 0 0;
      position: relative;
    }

    .fallacy-header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-right: 30px;
    }

    .fallacy-modal-header h2 {
      margin: 0;
      font-size: 18px;
      color: white;
      font-weight: 600;
    }

    .fallacy-bias-score {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .bias-score-circle {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 16px;
      font-weight: 700;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .bias-score-label {
      display: flex;
      flex-direction: column;
      color: white;
    }

    .bias-score-label strong {
      font-size: 14px;
      font-weight: 600;
    }

    .bias-score-label span {
      font-size: 11px;
      opacity: 0.9;
    }

    .fallacy-close-btn {
      position: absolute;
      top: 16px;
      right: 16px;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      font-size: 24px;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.2s;
      line-height: 1;
    }

    .fallacy-close-btn:hover {
      background: rgba(255, 255, 255, 0.3);
    }

    /* Loading Styles */
    .loading-body {
      padding: 40px 30px;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .loading-spinner {
      width: 60px;
      height: 60px;
      border: 4px solid #f3f4f6;
      border-top: 4px solid #667eea;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-bottom: 24px;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .loading-text {
      margin-bottom: 24px;
    }

    .loading-primary {
      font-size: 16px;
      font-weight: 600;
      color: #1e293b;
      margin: 0 0 8px;
    }

    .loading-secondary {
      font-size: 14px;
      color: #64748b;
      margin: 0 0 16px;
    }

    .loading-mode-badge {
      display: inline-block;
      padding: 6px 12px;
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      color: #1e40af;
    }

    .loading-progress {
      width: 100%;
      height: 4px;
      background: #f1f5f9;
      border-radius: 2px;
      overflow: hidden;
    }

    .loading-progress-bar {
      height: 100%;
      background: linear-gradient(90deg, #667eea, #764ba2);
      border-radius: 2px;
      animation: progressIndeterminate 1.5s ease-in-out infinite;
    }

    @keyframes progressIndeterminate {
      0% {
        width: 0%;
        margin-left: 0%;
      }
      50% {
        width: 40%;
        margin-left: 30%;
      }
      100% {
        width: 0%;
        margin-left: 100%;
      }
    }

    /* Results Styles */
    .fallacy-modal-body {
      padding: 20px;
      overflow-y: auto;
      flex: 1;
      max-height: calc(100vh - 280px);
    }

    .fallacy-section {
      margin-bottom: 20px;
    }

    .fallacy-section:last-child {
      margin-bottom: 0;
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .fallacy-section h3 {
      margin: 0 0 12px;
      font-size: 13px;
      color: #374151;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .text-length {
      font-size: 11px;
      color: #9ca3af;
    }

    .analyzed-text {
      background: #f9fafb;
      padding: 12px;
      border-radius: 6px;
      font-size: 13px;
      color: #6b7280;
      line-height: 1.6;
      border-left: 3px solid #667eea;
    }

    .analysis-content {
      font-size: 14px;
      color: #374151;
      line-height: 1.8;
      white-space: pre-wrap;
    }

    .fallacy-modal-footer {
      padding: 16px 20px;
      border-top: 1px solid #e5e7eb;
      background: #f9fafb;
      border-radius: 0 0 12px 12px;
    }

    .footer-actions {
      display: flex;
      gap: 8px;
      margin-bottom: 12px;
      flex-wrap: wrap;
    }

    .footer-primary {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
    }

    .action-btn {
      padding: 8px 14px;
      border: none;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      font-family: inherit;
    }

    .action-btn.secondary {
      background: white;
      color: #374151;
      border: 1px solid #d1d5db;
    }

    .action-btn.secondary:hover {
      background: #f3f4f6;
      border-color: #9ca3af;
    }

    .action-btn.primary {
      background: #667eea;
      color: white;
      border: 1px solid #667eea;
    }

    .action-btn.primary:hover {
      background: #5568d3;
      border-color: #5568d3;
    }

    .action-btn:active {
      transform: translateY(1px);
    }

    /* Scrollbar styling */
    .fallacy-modal-body::-webkit-scrollbar {
      width: 8px;
    }

    .fallacy-modal-body::-webkit-scrollbar-track {
      background: #f1f1f1;
    }

    .fallacy-modal-body::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }

    .fallacy-modal-body::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
  `;
  modal.appendChild(style);

  document.body.appendChild(modal);
}

// Smart bias score extraction with fallback
function calculateBiasScore(analysis) {
  // Method 1: Try to extract Claude's score
  const scoreMatch = analysis.match(/BIAS_SCORE:\s*(\d+)\/10/i);
  
  if (scoreMatch) {
    const score = parseInt(scoreMatch[1]);
    console.log('Using Claude-provided score:', score);
    return getScoreDetails(score);
  }
  
  // Method 2: Fallback to heuristic analysis
  console.log('No explicit score found, using fallback heuristic');
  return calculateHeuristicScore(analysis);
}

// Convert numeric score to label and color
function getScoreDetails(score) {
  if (score >= 9) return { score, label: 'Very Low Bias', color: '#10b981' };
  if (score >= 7) return { score, label: 'Low Bias', color: '#22c55e' };
  if (score >= 5) return { score, label: 'Moderate Bias', color: '#f59e0b' };
  if (score >= 3) return { score, label: 'High Bias', color: '#f97316' };
  return { score, label: 'Very High Bias', color: '#ef4444' };
}

// Fallback heuristic scoring (old method)
function calculateHeuristicScore(analysis) {
  const text = analysis.toLowerCase();
  
  // Count fallacy mentions
  const fallacyKeywords = [
    'ad hominem', 'strawman', 'false dichotomy', 'slippery slope',
    'appeal to emotion', 'confirmation bias', 'cherry picking',
    'hasty generalization', 'red herring', 'appeal to authority',
    'bandwagon', 'false cause', 'loaded language', 'whataboutism',
    'anecdotal evidence'
  ];
  
  let fallacyCount = 0;
  fallacyKeywords.forEach(keyword => {
    const regex = new RegExp(keyword, 'gi');
    const matches = text.match(regex);
    if (matches) fallacyCount += matches.length;
  });
  
  // Check for "no fallacies" indicators
  const noFallacies = text.includes('no significant fallacies') || 
                      text.includes('no major fallacies') ||
                      text.includes('no fallacies found') ||
                      text.includes('does not contain');
  
  if (noFallacies) return { score: 10, label: 'Low Bias', color: '#10b981' };
  
  // Score based on fallacy count
  if (fallacyCount === 0) return { score: 9, label: 'Very Low Bias', color: '#10b981' };
  if (fallacyCount === 1) return { score: 7, label: 'Low Bias', color: '#22c55e' };
  if (fallacyCount === 2) return { score: 5, label: 'Moderate Bias', color: '#f59e0b' };
  if (fallacyCount === 3) return { score: 3, label: 'High Bias', color: '#f97316' };
  return { score: 1, label: 'Very High Bias', color: '#ef4444' };
}

// Re-run analysis
function rerunAnalysis(mode = 'fast') {
  if (!currentText) return;
  
  // Show loading immediately
  showLoadingModal(mode);
  
  // Send message to background to re-analyze
  chrome.runtime.sendMessage({
    action: 'analyzeText',
    text: currentText,
    mode: mode
  });
}

// Download analysis
function downloadAnalysis() {
  if (!currentAnalysis) return;
  
  // Remove BIAS_SCORE line from download (internal formatting)
  const cleanAnalysis = currentAnalysis.replace(/BIAS_SCORE:\s*\d+\/10\s*/i, '');
  
  const blob = new Blob([cleanAnalysis], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `fallacy-analysis-${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Create and show modal with analysis results
function showAnalysisModal(analysis, originalText, selectedBiases = []) {
  // Remove any existing modal (including loading)
  const existingModal = document.getElementById('fallacy-detector-modal');
  if (existingModal) {
    existingModal.remove();
  }

  const biasScore = calculateBiasScore(analysis);
  
  // Remove BIAS_SCORE line from displayed analysis (it's just for parsing)
  const displayAnalysis = analysis.replace(/BIAS_SCORE:\s*\d+\/10\s*/i, '').trim();

  // Create modal
  const modal = document.createElement('div');
  modal.id = 'fallacy-detector-modal';
  modal.innerHTML = `
    <div class="fallacy-modal-container">
      <div class="fallacy-modal-header">
        <div class="fallacy-header-content">
          <h2>🎯 Fallacy Analysis</h2>
          <div class="fallacy-bias-score">
            <div class="bias-score-circle" style="background: ${biasScore.color}">
              ${biasScore.score}/10
            </div>
            <div class="bias-score-label">
              <strong>${biasScore.label}</strong>
              <span>AI-Rated</span>
            </div>
          </div>
        </div>
        <button class="fallacy-close-btn" id="fallacy-close">×</button>
      </div>
      
      <div class="fallacy-modal-body">
        <div class="fallacy-section">
          <div class="section-header">
            <h3>📄 Analyzed Text</h3>
            <span class="text-length">${originalText.length} characters</span>
          </div>
          <div class="analyzed-text">${escapeHtml(originalText.substring(0, 300))}${originalText.length > 300 ? '...' : ''}</div>
        </div>
        
        ${selectedBiases && selectedBiases.length > 0 ? `
        <div class="fallacy-section">
          <div class="section-header">
            <h3>✅ Checked For</h3>
            <span class="text-length">${selectedBiases.length} biases</span>
          </div>
          <div class="checked-biases">
            ${selectedBiases.map(bias => `<span class="bias-tag">${formatBiasName(bias)}</span>`).join('')}
          </div>
        </div>
        ` : ''}
        
        <div class="fallacy-section">
          <h3>🔍 Analysis Results</h3>
          <div class="analysis-content">${formatAnalysis(displayAnalysis)}</div>
        </div>
      </div>
      
      <div class="fallacy-modal-footer">
        <div class="footer-actions">
          <button class="action-btn secondary" id="fallacy-rerun">
            🔄 Re-run (Fast)
          </button>
          <button class="action-btn secondary" id="fallacy-detailed">
            🎯 Detailed Analysis
          </button>
          <button class="action-btn secondary" id="fallacy-download">
            📥 Download
          </button>
        </div>
        <div class="footer-primary">
          <button class="action-btn secondary" id="fallacy-copy">
            📋 Copy
          </button>
          <button class="action-btn primary" id="fallacy-done">
            Done
          </button>
        </div>
      </div>
    </div>
  `;

  // Add all the styles (same as loading modal)
  const style = document.createElement('style');
  style.textContent = `
    #fallacy-detector-modal {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 450px;
      max-height: calc(100vh - 40px);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      animation: slideIn 0.3s ease;
    }

    @keyframes slideIn {
      from {
        transform: translateX(500px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }

    .fallacy-modal-container {
      background: white;
      border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      display: flex;
      flex-direction: column;
      max-height: calc(100vh - 40px);
    }

    .fallacy-modal-container.loading {
      height: auto;
    }

    .fallacy-modal-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 20px;
      border-radius: 12px 12px 0 0;
      position: relative;
    }

    .fallacy-header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-right: 30px;
    }

    .fallacy-modal-header h2 {
      margin: 0;
      font-size: 18px;
      color: white;
      font-weight: 600;
    }

    .fallacy-bias-score {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .bias-score-circle {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-size: 16px;
      font-weight: 700;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .bias-score-label {
      display: flex;
      flex-direction: column;
      color: white;
    }

    .bias-score-label strong {
      font-size: 14px;
      font-weight: 600;
    }

    .bias-score-label span {
      font-size: 11px;
      opacity: 0.9;
    }

    .fallacy-close-btn {
      position: absolute;
      top: 16px;
      right: 16px;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      font-size: 24px;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.2s;
      line-height: 1;
    }

    .fallacy-close-btn:hover {
      background: rgba(255, 255, 255, 0.3);
    }

    /* Loading Styles */
    .loading-body {
      padding: 40px 30px;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .loading-spinner {
      width: 60px;
      height: 60px;
      border: 4px solid #f3f4f6;
      border-top: 4px solid #667eea;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin-bottom: 24px;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .loading-text {
      margin-bottom: 24px;
    }

    .loading-primary {
      font-size: 16px;
      font-weight: 600;
      color: #1e293b;
      margin: 0 0 8px;
    }

    .loading-secondary {
      font-size: 14px;
      color: #64748b;
      margin: 0 0 16px;
    }

    .loading-mode-badge {
      display: inline-block;
      padding: 6px 12px;
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      color: #1e40af;
    }

    .loading-progress {
      width: 100%;
      height: 4px;
      background: #f1f5f9;
      border-radius: 2px;
      overflow: hidden;
    }

    .loading-progress-bar {
      height: 100%;
      background: linear-gradient(90deg, #667eea, #764ba2);
      border-radius: 2px;
      animation: progressIndeterminate 1.5s ease-in-out infinite;
    }

    @keyframes progressIndeterminate {
      0% {
        width: 0%;
        margin-left: 0%;
      }
      50% {
        width: 40%;
        margin-left: 30%;
      }
      100% {
        width: 0%;
        margin-left: 100%;
      }
    }

    /* Results Styles */
    .fallacy-modal-body {
      padding: 20px;
      overflow-y: auto;
      flex: 1;
      max-height: calc(100vh - 280px);
    }

    .fallacy-section {
      margin-bottom: 20px;
    }

    .fallacy-section:last-child {
      margin-bottom: 0;
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .fallacy-section h3 {
      margin: 0 0 12px;
      font-size: 13px;
      color: #374151;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .text-length {
      font-size: 11px;
      color: #9ca3af;
    }

    .analyzed-text {
      background: #f9fafb;
      padding: 12px;
      border-radius: 6px;
      font-size: 13px;
      line-height: 1.6;
      color: #4b5563;
      border: 1px solid #e5e7eb;
    }

    .checked-biases {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .bias-tag {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 6px 12px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 500;
      display: inline-block;
      box-shadow: 0 2px 4px rgba(102, 126, 234, 0.2);
    }

    .analysis-content {
      background: #ffffff;
      padding: 16px;
      border-radius: 6px;
      font-size: 14px;
      line-height: 1.7;
      color: #1f2937;
      border: 1px solid #e5e7eb;
    }

    .analysis-content strong {
      color: #667eea;
      font-weight: 600;
    }

    /* Footer */
    .fallacy-modal-footer {
      padding: 16px 20px;
      background: #f9fafb;
      border-top: 1px solid #e5e7eb;
      border-radius: 0 0 12px 12px;
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
    }

    .footer-actions {
      display: flex;
      gap: 8px;
      flex: 1;
    }

    .footer-primary {
      display: flex;
      gap: 8px;
    }

    .action-btn {
      padding: 8px 14px;
      border: none;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s;
      font-family: inherit;
    }

    .action-btn.secondary {
      background: white;
      color: #374151;
      border: 1px solid #d1d5db;
    }

    .action-btn.secondary:hover {
      background: #f3f4f6;
      border-color: #9ca3af;
    }

    .action-btn.primary {
      background: #667eea;
      color: white;
      border: 1px solid #667eea;
    }

    .action-btn.primary:hover {
      background: #5568d3;
      border-color: #5568d3;
    }

    .action-btn:active {
      transform: translateY(1px);
    }

    /* Scrollbar styling */
    .fallacy-modal-body::-webkit-scrollbar {
      width: 8px;
    }

    .fallacy-modal-body::-webkit-scrollbar-track {
      background: #f1f1f1;
    }

    .fallacy-modal-body::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }

    .fallacy-modal-body::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }
  `;
  modal.appendChild(style);

  document.body.appendChild(modal);

  // Event listeners
  document.getElementById('fallacy-close').addEventListener('click', () => modal.remove());
  document.getElementById('fallacy-done').addEventListener('click', () => modal.remove());
  
  document.getElementById('fallacy-copy').addEventListener('click', () => {
    const cleanAnalysis = currentAnalysis.replace(/BIAS_SCORE:\s*\d+\/10\s*/i, '').trim();
    navigator.clipboard.writeText(cleanAnalysis).then(() => {
      const btn = document.getElementById('fallacy-copy');
      btn.textContent = '✓ Copied!';
      btn.style.background = '#10b981';
      btn.style.borderColor = '#10b981';
      btn.style.color = 'white';
      setTimeout(() => {
        btn.textContent = '📋 Copy';
        btn.style.background = '';
        btn.style.borderColor = '';
        btn.style.color = '';
      }, 2000);
    });
  });

  document.getElementById('fallacy-rerun').addEventListener('click', () => {
    rerunAnalysis('fast');
  });

  document.getElementById('fallacy-detailed').addEventListener('click', () => {
    rerunAnalysis('accurate');
  });

  document.getElementById('fallacy-download').addEventListener('click', () => {
    downloadAnalysis();
  });

  // Close on Escape
  const escapeHandler = (e) => {
    if (e.key === 'Escape') {
      modal.remove();
      document.removeEventListener('keydown', escapeHandler);
    }
  };
  document.addEventListener('keydown', escapeHandler);
}

// Helper functions
function formatBiasName(biasId) {
  const biasNames = {
    'ad_hominem': 'Ad Hominem',
    'strawman': 'Strawman',
    'false_dichotomy': 'False Dichotomy',
    'slippery_slope': 'Slippery Slope',
    'appeal_to_emotion': 'Appeal to Emotion',
    'confirmation_bias': 'Confirmation Bias',
    'hasty_generalization': 'Hasty Generalization',
    'red_herring': 'Red Herring',
    'appeal_to_authority': 'Appeal to Authority',
    'bandwagon': 'Bandwagon',
    'cherry_picking': 'Cherry Picking',
    'false_cause': 'False Cause',
    'loaded_language': 'Loaded Language',
    'whataboutism': 'Whataboutism',
    'anecdotal_evidence': 'Anecdotal Evidence'
  };
  return biasNames[biasId] || biasId;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function formatAnalysis(text) {
  let formatted = escapeHtml(text);
  formatted = formatted.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  formatted = formatted.replace(/\n/g, '<br>');
  return formatted;
}
