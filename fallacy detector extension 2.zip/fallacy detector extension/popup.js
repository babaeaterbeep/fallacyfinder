// Simplified popup.js for proxy mode - no API key management

// Load saved settings
document.addEventListener('DOMContentLoaded', async () => {
  const settings = await chrome.storage.sync.get({
    analysisMode: 'fast',
    selectedBiases: ['ad_hominem', 'strawman', 'false_dichotomy', 'slippery_slope', 'appeal_to_emotion', 'confirmation_bias', 'hasty_generalization', 'red_herring', 'appeal_to_authority', 'bandwagon', 'cherry_picking', 'false_cause', 'loaded_language', 'whataboutism', 'anecdotal_evidence']
  });
  
  // Set mode
  document.getElementById('analysisMode').value = settings.analysisMode;
});

// Save settings
document.getElementById('saveSettings').addEventListener('click', async () => {
  const mode = document.getElementById('analysisMode').value;
  
  await chrome.storage.sync.set({
    analysisMode: mode
  });
  
  // Visual feedback
  const btn = document.getElementById('saveSettings');
  const originalText = btn.textContent;
  btn.textContent = '✓ Saved!';
  btn.style.background = '#10b981';
  
  setTimeout(() => {
    btn.textContent = originalText;
    btn.style.background = '';
  }, 2000);
});

// Configure biases button
document.getElementById('configureBiases').addEventListener('click', () => {
  // Open as extension tab (has full permissions)
  chrome.tabs.create({
    url: chrome.runtime.getURL('bias-config-simple.html')
  });
});

// Feedback link
document.getElementById('feedbackLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({
    url: 'https://docs.google.com/forms/d/e/1FAIpQLSewsPpAKGvzyijEzkd_2iRkai4pi_iclYbYqoE7TPYpcQg30w/viewform'  // Replace with your Google Form
  });
});

// Help link
document.getElementById('helpLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({
    url: 'https://github.com/yourusername/fallacy-detector#readme'
  });
});
