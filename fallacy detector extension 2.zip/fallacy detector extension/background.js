// Background script with retry logic for stability
const PROXY_URL = 'https://fallacy-detector-api.fallacy-detector-apibabaeater.workers.dev';

// Retry configuration
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function fetchWithRetry(url, options, retries = MAX_RETRIES) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      console.log(`Attempt ${attempt + 1}/${retries + 1} for API request`);
      
      const response = await fetch(url, options);
      const data = await response.json();
      
      if (response.ok) {
        console.log('API request successful');
        return { success: true, data };
      }
      
      if (response.status >= 500 && attempt < retries) {
        const delay = RETRY_DELAY_MS * Math.pow(2, attempt);
        console.log(`Server error (${response.status}), retrying in ${delay}ms...`);
        await sleep(delay);
        continue;
      }
      
      console.error('API request failed:', response.status, data);
      return {
        success: false,
        error: data.error || `Request failed with status ${response.status}`,
        status: response.status
      };
      
    } catch (error) {
      console.error(`Attempt ${attempt + 1} failed:`, error.message);
      
      if (attempt < retries) {
        const delay = RETRY_DELAY_MS * Math.pow(2, attempt);
        console.log(`Retrying in ${delay}ms...`);
        await sleep(delay);
        continue;
      }
      
      return {
        success: false,
        error: `Network error: ${error.message}`
      };
    }
  }
}

// Ensure content script is injected and ready
async function ensureContentScriptReady(tabId) {
  try {
    // Try to ping the content script
    const response = await chrome.tabs.sendMessage(tabId, { action: 'ping' });
    return response?.ready === true;
  } catch (error) {
    // Content script not ready, inject it
    console.log('Content script not ready, injecting...');
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      });
      // Give it a moment to initialize
      await sleep(100);
      return true;
    } catch (injectError) {
      console.error('Failed to inject content script:', injectError);
      return false;
    }
  }
}

// Analyze text function (shared by context menu and re-run)
async function analyzeText(text, tab, mode = 'fast') {
  try {
    // Make sure content script is ready
    const isReady = await ensureContentScriptReady(tab.id);
    
    if (!isReady) {
      showNotification('Error', 'Could not initialize analysis. Please try again.');
      return;
    }

    // Show loading modal immediately
    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'showLoading',
        mode: mode
      });
      console.log('Loading modal shown');
    } catch (error) {
      console.error('Failed to show loading modal:', error);
      // Continue anyway, just show notification
    }

    const settings = await chrome.storage.sync.get({
      analysisMode: mode,
      selectedBiases: [
        'ad_hominem', 'strawman', 'false_dichotomy', 'slippery_slope',
        'appeal_to_emotion', 'confirmation_bias', 'hasty_generalization',
        'red_herring', 'appeal_to_authority', 'bandwagon', 'cherry_picking',
        'false_cause', 'loaded_language', 'whataboutism', 'anecdotal_evidence'
      ]
    });

    // Show notification as backup
    showNotification('Analyzing...', `Running ${mode} analysis. Please wait...`);

    const prompt = createAnalysisPrompt(text, settings.selectedBiases, mode);
    const model = 'claude-sonnet-4-20250514';
    const maxTokens = mode === 'accurate' ? 4096 : 2048;

    const result = await fetchWithRetry(PROXY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model,
        max_tokens: maxTokens,
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ]
      })
    });

    if (!result.success) {
      throw new Error(result.error || 'API request failed');
    }

    const analysis = result.data.content[0].text;
    
    // Send results - this will replace the loading modal
    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'showAnalysis',
        analysis: analysis,
        originalText: text,
        selectedBiases: settings.selectedBiases
      });
      console.log('Results sent to content script');
    } catch (error) {
      console.error('Failed to send results to content script:', error);
      showNotification('Analysis Complete', 'Check the page for results.');
    }

  } catch (error) {
    console.error('Error analyzing text:', error);
    
    // Try to remove loading modal if it's there
    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'hideLoading'
      });
    } catch (e) {
      // Ignore if content script not available
    }
    
    showNotification(
      'Analysis Failed',
      `Failed to analyze text: ${error.message}. Please try again.`
    );
  }
}

// Create context menu
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'checkFallacies',
    title: 'Check for Fallacies',
    contexts: ['selection']
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'checkFallacies' && info.selectionText) {
    const selectedText = info.selectionText.trim();
    
    if (selectedText.length < 50) {
      showNotification('Error', 'Please select more text (at least 50 characters) for meaningful analysis.');
      return;
    }
    
    if (selectedText.length > 10000) {
      showNotification('Error', 'Text too long. Please select less than 10,000 characters.');
      return;
    }

    await analyzeText(selectedText, tab, 'fast');
  }
});

// Listen for messages from content script (for re-run)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'analyzeText') {
    analyzeText(request.text, sender.tab, request.mode);
    sendResponse({ success: true });
  }
  return true;
});

// Helper function to create analysis prompt with scoring
function createAnalysisPrompt(text, selectedBiases, mode) {
  const biasDescriptions = {
    'ad_hominem': 'Ad Hominem (attacking the person, not the argument)',
    'strawman': 'Strawman (misrepresenting an argument)',
    'false_dichotomy': 'False Dichotomy (presenting only two options)',
    'slippery_slope': 'Slippery Slope (claiming extreme consequences)',
    'appeal_to_emotion': 'Appeal to Emotion (using emotions over logic)',
    'confirmation_bias': 'Confirmation Bias (cherry-picking supporting evidence)',
    'hasty_generalization': 'Hasty Generalization (broad conclusions from limited data)',
    'red_herring': 'Red Herring (introducing irrelevant information)',
    'appeal_to_authority': 'Appeal to Authority (citing authority without logic)',
    'bandwagon': 'Bandwagon (arguing popularity equals truth)',
    'cherry_picking': 'Cherry Picking (selective use of data)',
    'false_cause': 'False Cause (correlation equals causation)',
    'loaded_language': 'Loaded Language (emotionally charged words)',
    'whataboutism': 'Whataboutism (deflecting with other issues)',
    'anecdotal_evidence': 'Anecdotal Evidence (personal stories as proof)'
  };

  const biasesToCheck = selectedBiases.map(id => biasDescriptions[id]).join(', ');
  
  const detailLevel = mode === 'accurate' 
    ? 'Provide an extremely detailed analysis with extensive context, examples, and explanations for each finding.'
    : 'Provide a concise but clear analysis, highlighting the key issues.';

  return `Analyze the following text for logical fallacies and cognitive biases. Focus on these specific types: ${biasesToCheck}.

${detailLevel}

IMPORTANT: Start your response with a bias score on the first line in this exact format:
BIAS_SCORE: X/10

Where X is a number from 1-10 based on these criteria:

**Scoring Guide:**
- **10/10** - No fallacies detected. Logical, well-reasoned argument with solid evidence
- **9/10** - Minimal bias. Perhaps one minor stylistic issue (e.g., slight loaded language)
- **8/10** - Very slight bias. One minor fallacy that doesn't significantly impact the argument
- **7/10** - Low bias. One moderate fallacy or two minor ones
- **6/10** - Mild bias. Multiple minor fallacies or one notable fallacy
- **5/10** - Moderate bias. Several fallacies present, mix of minor and moderate severity
- **4/10** - Significant bias. Multiple moderate fallacies or one severe fallacy
- **3/10** - High bias. Several significant fallacies that undermine the argument
- **2/10** - Very high bias. Numerous serious fallacies throughout
- **1/10** - Extreme bias. Argument is almost entirely based on fallacious reasoning

Consider these factors when scoring:
- **Severity:** Major fallacies (ad hominem, strawman) vs minor issues (slight loaded language)
- **Frequency:** How many fallacies relative to text length
- **Impact:** Do the fallacies undermine the core argument or are they peripheral?
- **Intent:** Does it seem intentionally manipulative or just poor reasoning?

After the score, provide your detailed analysis:

For each fallacy or bias you find:
1. Quote the specific passage
2. Explain which fallacy/bias it represents
3. Explain why it's problematic and its impact on the argument

If no significant fallacies are found, explain why the text is logically sound.

Text to analyze:
"""
${text}
"""

Remember: Start with "BIAS_SCORE: X/10" on the first line, then provide your analysis.`;
}

// Helper function to show notifications
function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icon128.png',
    title: title,
    message: message,
    priority: 2
  });
}
