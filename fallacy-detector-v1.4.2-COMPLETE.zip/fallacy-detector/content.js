// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FALLACY_LOADING') {
    showLoadingPopup(message.runs);
  } else if (message.type === 'FALLACY_RESULT') {
    if (message.error) {
      showErrorPopup(message.error);
    } else {
      showResultPopup(message.data, message.originalText);
    }
  }
});

function showLoadingPopup(runs) {
  removeExistingPopup();
  
  const popup = createPopup();
  const runsText = runs > 1 ? ` (${runs} runs)` : '';
  popup.innerHTML = `
    <div class="fallacy-header">
      <h3>🔍 Analyzing${runsText}...</h3>
    </div>
    <div class="fallacy-body">
      <div class="loading-spinner"></div>
      <p>Checking for logical fallacies...</p>
      ${runs > 1 ? `<p style="font-size: 12px; color: #64748b; margin-top: 8px;">Running ${runs} analyses for consistency</p>` : ''}
    </div>
  `;
  
  document.body.appendChild(popup);
}

function showErrorPopup(error) {
  removeExistingPopup();
  
  const popup = createPopup();
  popup.innerHTML = `
    <div class="fallacy-header error">
      <h3>⚠️ Error</h3>
    </div>
    <div class="fallacy-body">
      <p>${error}</p>
    </div>
    <div class="fallacy-footer">
      <button class="close-btn">Close</button>
    </div>
  `;
  
  popup.querySelector('.close-btn').addEventListener('click', () => {
    removeExistingPopup();
  });
  
  document.body.appendChild(popup);
}

function showResultPopup(data, originalText) {
  removeExistingPopup();
  
  const popup = createPopup();
  
  const biasColor = data.bias_score > 7 ? '#ef4444' : data.bias_score > 4 ? '#f59e0b' : '#10b981';
  
  // Text quality warning
  let textQualityWarning = '';
  if (data.text_quality === 'non-article') {
    textQualityWarning = `
      <div class="warning-box">
        ⚠️ Warning: Selected text may include non-article content (menus, ads, etc.). Please re-select only article text for accurate analysis.
      </div>
    `;
  } else if (data.text_quality === 'mixed') {
    textQualityWarning = `
      <div class="warning-box" style="background: #fef3c7; border-left-color: #f59e0b;">
        ℹ️ Note: Selected text may include some non-article content. Results may be affected.
      </div>
    `;
  }
  
  let fallaciesHtml = '';
  if (data.fallacies && data.fallacies.length > 0) {
    fallaciesHtml = data.fallacies.map(fallacy => {
      const severityEmoji = fallacy.severity === 'high' ? '🔴' : fallacy.severity === 'medium' ? '🟡' : '🟢';
      return `
        <div class="fallacy-item severity-${fallacy.severity}">
          <div class="fallacy-type">${severityEmoji} ${fallacy.type}</div>
          <div class="fallacy-explanation">${fallacy.explanation}</div>
        </div>
      `;
    }).join('');
  } else {
    fallaciesHtml = '<div class="no-fallacies">✅ No obvious fallacies detected</div>';
  }
  
  // Individual scores display
  const individualScores = data.individual_scores || [data.bias_score];
  const scoresDisplay = individualScores.length > 1 
    ? `<div class="scores-detail">Individual scores: ${individualScores.join(', ')}</div>`
    : '';
  
  // Confidence display
  const confidenceColor = data.confidence > 80 ? '#10b981' : data.confidence > 60 ? '#f59e0b' : '#ef4444';
  const confidenceDisplay = data.confidence 
    ? `<div class="confidence-meter">Confidence: <strong style="color: ${confidenceColor}">${data.confidence}%</strong></div>`
    : '';
  
  // Bias selection display
  const BIAS_NAMES = {
    ad_hominem: 'Ad Hominem',
    strawman: 'Strawman',
    false_dichotomy: 'False Dichotomy',
    slippery_slope: 'Slippery Slope',
    appeal_to_emotion: 'Appeal to Emotion',
    confirmation_bias: 'Confirmation Bias',
    hasty_generalization: 'Hasty Generalization',
    red_herring: 'Red Herring',
    appeal_to_authority: 'Appeal to Authority',
    bandwagon: 'Bandwagon',
    cherry_picking: 'Cherry Picking',
    false_cause: 'False Cause',
    loaded_language: 'Loaded Language',
    whataboutism: 'Whataboutism',
    anecdotal_evidence: 'Anecdotal Evidence'
  };
  
  let biasCheckDisplay = '';
  if (data.selectedBiases && data.selectedBiases.length < 15) {
    const biasNames = data.selectedBiases.map(id => BIAS_NAMES[id]).join(', ');
    biasCheckDisplay = `<div class="biases-checked">🎯 Checked for: ${biasNames}</div>`;
  }
  
  popup.innerHTML = `
    <div class="fallacy-header">
      <h3>🎯 Fallacy Analysis</h3>
      <button class="close-btn-x">×</button>
    </div>
    <div class="fallacy-body">
      ${textQualityWarning}
      
      <div class="bias-meter">
        <div class="bias-label">Bias Score: <strong style="color: ${biasColor}">${data.bias_score}/10</strong></div>
        ${scoresDisplay}
        ${confidenceDisplay}
        <div class="bias-bar">
          <div class="bias-fill" style="width: ${data.bias_score * 10}%; background: ${biasColor}"></div>
        </div>
        ${data.runs && data.runs > 1 ? `<div class="runs-note">Based on ${data.runs} analyses (${data.mode || 'accurate'} mode)</div>` : data.runs === 1 ? `<div class="runs-note">Fast mode (single analysis)</div>` : ''}
        ${data.mode === 'fast' || data.runs === 1 ? `<div class="variance-warning">⚠️ Fast mode may vary ±2 points. Use Accurate mode for precision.</div>` : ''}
        ${biasCheckDisplay}
      </div>
      
      ${fallaciesHtml}
      
      ${data.overall_assessment ? `
        <div class="overall-assessment">
          <strong>Assessment:</strong> ${data.overall_assessment}
        </div>
      ` : ''}
    </div>
    <div class="fallacy-footer">
      ${data.mode === 'fast' || data.runs === 1 ? `<button class="run-accurate-btn">🎯 Run Accurate Check</button>` : ''}
      <button class="rerun-btn">🔄 Re-run Analysis</button>
      <button class="download-btn">Download Analysis</button>
      <button class="close-btn">Close</button>
    </div>
  `;
  
  popup.querySelector('.close-btn').addEventListener('click', () => {
    removeExistingPopup();
  });
  
  popup.querySelector('.close-btn-x').addEventListener('click', () => {
    removeExistingPopup();
  });
  
  // Download analysis functionality
  popup.querySelector('.download-btn').addEventListener('click', () => {
    downloadAnalysis(data, originalText);
  });
  
  // Re-run analysis functionality
  popup.querySelector('.rerun-btn').addEventListener('click', () => {
    // Store the original text in the popup element
    removeExistingPopup();
    // Trigger a new analysis on the same text
    chrome.runtime.sendMessage({
      type: 'RERUN_ANALYSIS',
      text: originalText
    });
  });
  
  // Run Accurate button (only present in Fast mode results)
  const runAccurateBtn = popup.querySelector('.run-accurate-btn');
  if (runAccurateBtn) {
    runAccurateBtn.addEventListener('click', () => {
      removeExistingPopup();
      // Trigger analysis with Accurate mode override
      chrome.runtime.sendMessage({
        type: 'RUN_ACCURATE_ANALYSIS',
        text: originalText
      });
    });
  }
  
  // Store original text in popup for re-run
  popup.dataset.originalText = originalText;
  
  document.body.appendChild(popup);
  
  // Removed auto-close - user controls when to close
}

function createPopup() {
  const popup = document.createElement('div');
  popup.id = 'fallacy-detector-popup';
  popup.className = 'fallacy-popup';
  return popup;
}

function removeExistingPopup() {
  const existing = document.getElementById('fallacy-detector-popup');
  if (existing) {
    existing.remove();
  }
}

function downloadAnalysis(data, originalText) {
  // Create formatted text content
  const timestamp = new Date().toLocaleString();
  let content = `FALLACY ANALYSIS\n`;
  content += `Date: ${timestamp}\n`;
  content += `${'='.repeat(60)}\n\n`;
  
  content += `ANALYZED TEXT:\n`;
  content += `${originalText}\n\n`;
  content += `${'='.repeat(60)}\n\n`;
  
  content += `BIAS SCORE: ${data.bias_score}/10\n`;
  
  if (data.individual_scores && data.individual_scores.length > 1) {
    content += `Individual Scores: ${data.individual_scores.join(', ')}\n`;
    content += `(Based on ${data.runs || 3} analyses for consistency)\n`;
  }
  
  if (data.confidence) {
    content += `Confidence: ${data.confidence}%\n`;
  }
  
  if (data.text_quality && data.text_quality !== 'article') {
    content += `Text Quality: ${data.text_quality}\n`;
  }
  
  content += `\n`;
  
  if (data.fallacies && data.fallacies.length > 0) {
    content += `DETECTED FALLACIES:\n\n`;
    data.fallacies.forEach((fallacy, index) => {
      content += `${index + 1}. ${fallacy.type.toUpperCase()} [${fallacy.severity}]\n`;
      content += `   ${fallacy.explanation}\n\n`;
    });
  } else {
    content += `DETECTED FALLACIES:\nNone - No obvious fallacies detected.\n\n`;
  }
  
  if (data.overall_assessment) {
    content += `${'='.repeat(60)}\n\n`;
    content += `OVERALL ASSESSMENT:\n`;
    content += `${data.overall_assessment}\n`;
  }
  
  // Create download
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `fallacy-analysis-${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Inject styles
const style = document.createElement('style');
style.textContent = `
  .fallacy-popup {
    position: fixed;
    top: 20px;
    right: 20px;
    width: 400px;
    max-height: 600px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
    z-index: 999999;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow: hidden;
    animation: slideIn 0.3s ease-out;
  }
  
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  .fallacy-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 16px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .fallacy-header.error {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  }
  
  .fallacy-header h3 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
  }
  
  .close-btn-x {
    background: none;
    border: none;
    color: white;
    font-size: 28px;
    cursor: pointer;
    line-height: 1;
    padding: 0;
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    transition: background 0.2s;
  }
  
  .close-btn-x:hover {
    background: rgba(255, 255, 255, 0.2);
  }
  
  .fallacy-body {
    padding: 20px;
    max-height: 450px;
    overflow-y: auto;
  }
  
  .warning-box {
    margin-bottom: 15px;
    padding: 12px;
    background: #fee2e2;
    border-left: 4px solid #ef4444;
    border-radius: 4px;
    font-size: 13px;
    color: #991b1b;
    line-height: 1.5;
  }
  
  .bias-meter {
    margin-bottom: 20px;
    padding: 15px;
    background: #f8fafc;
    border-radius: 8px;
  }
  
  .bias-label {
    margin-bottom: 8px;
    font-size: 14px;
    color: #475569;
  }
  
  .scores-detail {
    margin-top: 4px;
    font-size: 12px;
    color: #64748b;
  }
  
  .confidence-meter {
    margin-top: 6px;
    font-size: 12px;
    color: #475569;
  }
  
  .runs-note {
    margin-top: 8px;
    font-size: 11px;
    color: #94a3b8;
    font-style: italic;
  }
  
  .variance-warning {
    margin-top: 6px;
    padding: 8px 10px;
    background: #fef3c7;
    border-left: 3px solid #f59e0b;
    border-radius: 4px;
    font-size: 11px;
    color: #92400e;
    line-height: 1.4;
  }
  
  .biases-checked {
    margin-top: 6px;
    padding: 8px 10px;
    background: #f0f9ff;
    border-left: 3px solid #3b82f6;
    border-radius: 4px;
    font-size: 11px;
    color: #1e40af;
    line-height: 1.4;
  }
  
  .bias-bar {
    height: 8px;
    background: #e2e8f0;
    border-radius: 4px;
    overflow: hidden;
  }
  
  .bias-fill {
    height: 100%;
    transition: width 0.5s ease-out;
  }
  
  .fallacy-item {
    margin-bottom: 16px;
    padding: 12px;
    border-left: 4px solid #94a3b8;
    background: #f8fafc;
    border-radius: 4px;
  }
  
  .fallacy-item.severity-high {
    border-left-color: #ef4444;
  }
  
  .fallacy-item.severity-medium {
    border-left-color: #f59e0b;
  }
  
  .fallacy-item.severity-low {
    border-left-color: #10b981;
  }
  
  .fallacy-type {
    font-weight: 600;
    color: #1e293b;
    margin-bottom: 6px;
    font-size: 14px;
  }
  
  .fallacy-explanation {
    font-size: 13px;
    color: #475569;
    line-height: 1.5;
  }
  
  .no-fallacies {
    padding: 20px;
    text-align: center;
    color: #10b981;
    font-weight: 500;
    font-size: 16px;
  }
  
  .overall-assessment {
    margin-top: 16px;
    padding: 12px;
    background: #f1f5f9;
    border-radius: 6px;
    font-size: 13px;
    color: #475569;
    line-height: 1.6;
  }
  
  .overall-assessment strong {
    color: #1e293b;
  }
  
  .fallacy-footer {
    padding: 16px 20px;
    border-top: 1px solid #e2e8f0;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
  }
  
  .run-accurate-btn {
    background: #3b82f6;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s;
  }
  
  .run-accurate-btn:hover {
    background: #2563eb;
  }
  
  .rerun-btn {
    background: #8b5cf6;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s;
  }
  
  .rerun-btn:hover {
    background: #7c3aed;
  }
  
  .download-btn {
    background: #10b981;
    color: white;
    border: none;
    padding: 8px 20px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s;
  }
  
  .download-btn:hover {
    background: #059669;
  }
  
  .close-btn {
    background: #667eea;
    color: white;
    border: none;
    padding: 8px 20px;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    transition: background 0.2s;
  }
  
  .close-btn:hover {
    background: #5568d3;
  }
  
  .loading-spinner {
    border: 3px solid #e2e8f0;
    border-top: 3px solid #667eea;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
    margin: 20px auto;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`;
document.head.appendChild(style);
