// Available cognitive biases with descriptions
const AVAILABLE_BIASES = [
  { id: 'ad_hominem', name: 'Ad Hominem', description: 'Attacking the person, not the argument' },
  { id: 'strawman', name: 'Strawman', description: 'Misrepresenting the argument' },
  { id: 'false_dichotomy', name: 'False Dichotomy', description: 'Only two options when more exist' },
  { id: 'slippery_slope', name: 'Slippery Slope', description: 'One thing will lead to extreme consequences' },
  { id: 'appeal_to_emotion', name: 'Appeal to Emotion', description: 'Using emotions instead of logic' },
  { id: 'confirmation_bias', name: 'Confirmation Bias', description: 'Only seeing evidence that confirms beliefs' },
  { id: 'hasty_generalization', name: 'Hasty Generalization', description: 'Broad conclusion from limited evidence' },
  { id: 'red_herring', name: 'Red Herring', description: 'Distracting from the main point' },
  { id: 'appeal_to_authority', name: 'Appeal to Authority', description: 'Citing authority as sole evidence' },
  { id: 'bandwagon', name: 'Bandwagon', description: 'Everyone believes it, so it must be true' },
  { id: 'cherry_picking', name: 'Cherry Picking', description: 'Selective use of data/quotes to support one view' },
  { id: 'false_cause', name: 'False Cause', description: 'Assuming correlation equals causation' },
  { id: 'loaded_language', name: 'Loaded Language', description: 'Emotionally charged words by author' },
  { id: 'whataboutism', name: 'Whataboutism', description: 'Deflecting criticism by pointing to other issues' },
  { id: 'anecdotal_evidence', name: 'Anecdotal Evidence', description: 'Using personal stories as primary proof' }
];

// Load saved settings and update UI on popup open
document.addEventListener('DOMContentLoaded', async () => {
  const { apiKey } = await chrome.storage.sync.get(['apiKey']);
  if (apiKey) {
    document.getElementById('apiKey').value = apiKey;
    updateApiStatus(true);
  } else {
    updateApiStatus(false);
  }
  
  const settings = await chrome.storage.sync.get({
    analysisMode: 'fast',
    customRuns: 5,
    selectedBiases: AVAILABLE_BIASES.map(b => b.id)
  });
  
  document.getElementById('analysisMode').value = settings.analysisMode;
  document.getElementById('customRuns').value = settings.customRuns;
  toggleCustomRuns(settings.analysisMode);
  updateBiasCount(settings.selectedBiases.length);
  updateCurrentStatus(settings);
  populateBiasList(settings.selectedBiases);
});

function updateApiStatus(hasKey) {
  const apiStatus = document.getElementById('apiStatus');
  if (hasKey) {
    apiStatus.innerHTML = '<span class="badge success">✓ Set</span>';
  } else {
    apiStatus.innerHTML = '<span class="badge">Not Set</span>';
  }
}

function updateCurrentStatus(settings) {
  // Update mode display
  const modeDisplay = {
    'fast': '⚡ Fast',
    'accurate': '🎯 Accurate',
    'custom': `⚙️ Custom (${settings.customRuns})`
  };
  document.getElementById('currentMode').textContent = modeDisplay[settings.analysisMode] || '⚡ Fast';
  
  // Update biases display
  const biasCount = settings.selectedBiases ? settings.selectedBiases.length : 15;
  document.getElementById('currentBiases').textContent = `${biasCount} active`;
}

function toggleCustomRuns(mode) {
  document.getElementById('customRunsGroup').style.display = mode === 'custom' ? 'block' : 'none';
}

function updateBiasCount(count) {
  document.getElementById('biasCount').textContent = count;
}

function populateBiasList(selectedBiases) {
  const biasList = document.getElementById('biasList');
  if (!biasList) return;
  
  biasList.innerHTML = '';
  AVAILABLE_BIASES.forEach(bias => {
    const isChecked = selectedBiases.includes(bias.id);
    const item = document.createElement('div');
    item.className = 'bias-item';
    item.innerHTML = `
      <input type="checkbox" id="bias_${bias.id}" ${isChecked ? 'checked' : ''}>
      <div class="bias-item-content">
        <div class="bias-item-name">${bias.name}</div>
        <div class="bias-item-description">${bias.description}</div>
      </div>
    `;
    item.addEventListener('click', (e) => {
      if (e.target.tagName !== 'INPUT') {
        item.querySelector('input').checked = !item.querySelector('input').checked;
      }
    });
    biasList.appendChild(item);
  });
}

// Analysis mode change handler
document.getElementById('analysisMode').addEventListener('change', (e) => {
  toggleCustomRuns(e.target.value);
});

// Save API Key ONLY
document.getElementById('saveBtn').addEventListener('click', async () => {
  const apiKey = document.getElementById('apiKey').value.trim();
  const statusDiv = document.getElementById('status');
  const saveBtn = document.getElementById('saveBtn');
  
  if (!apiKey) {
    showStatus(statusDiv, 'Please enter an API key', 'error');
    return;
  }
  
  if (!apiKey.startsWith('sk-ant-')) {
    showStatus(statusDiv, 'Invalid API key format. Should start with sk-ant-', 'error');
    return;
  }
  
  saveBtn.disabled = true;
  saveBtn.textContent = 'Saving...';
  
  try {
    await chrome.storage.sync.set({ apiKey });
    showStatus(statusDiv, '✓ API key saved successfully!', 'success');
    updateApiStatus(true);
    saveBtn.textContent = 'Saved!';
    
    setTimeout(() => {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save API Key';
    }, 2000);
    
  } catch (error) {
    showStatus(statusDiv, 'Error saving API key: ' + error.message, 'error');
    saveBtn.disabled = false;
    saveBtn.textContent = 'Save API Key';
  }
});

// Save Settings ONLY (separate from API key)
document.getElementById('saveSettingsBtn').addEventListener('click', async () => {
  const statusDiv = document.getElementById('settingsStatus');
  const analysisMode = document.getElementById('analysisMode').value;
  const customRuns = parseInt(document.getElementById('customRuns').value);
  
  // Validate custom runs
  if (analysisMode === 'custom' && (customRuns < 1 || customRuns > 100)) {
    showStatus(statusDiv, 'Custom runs must be between 1 and 100', 'error');
    return;
  }
  
  try {
    const currentSettings = await chrome.storage.sync.get(['selectedBiases', 'apiKey']);
    const newSettings = {
      analysisMode,
      customRuns,
      selectedBiases: currentSettings.selectedBiases || AVAILABLE_BIASES.map(b => b.id)
    };
    
    // Don't include apiKey in settings update
    await chrome.storage.sync.set(newSettings);
    
    showStatus(statusDiv, '✓ Settings updated!', 'success');
    updateCurrentStatus(newSettings);
    
  } catch (error) {
    showStatus(statusDiv, 'Error saving settings: ' + error.message, 'error');
  }
});

// Configure Biases button
const configureBiasesBtn = document.getElementById('configureBiasesBtn');
if (configureBiasesBtn) {
  configureBiasesBtn.addEventListener('click', () => {
    const modal = document.getElementById('biasModal');
    if (modal) modal.style.display = 'flex';
  });
}

// Close modal
const closeBiasModal = document.getElementById('closeBiasModal');
if (closeBiasModal) {
  closeBiasModal.addEventListener('click', () => {
    const modal = document.getElementById('biasModal');
    if (modal) modal.style.display = 'none';
  });
}

// Close modal on background click
const biasModal = document.getElementById('biasModal');
if (biasModal) {
  biasModal.addEventListener('click', (e) => {
    if (e.target.id === 'biasModal') {
      biasModal.style.display = 'none';
    }
  });
}

// Select All Biases
const selectAllBiases = document.getElementById('selectAllBiases');
if (selectAllBiases) {
  selectAllBiases.addEventListener('click', () => {
    document.querySelectorAll('.bias-item input[type="checkbox"]').forEach(cb => cb.checked = true);
  });
}

// Deselect All Biases
const deselectAllBiases = document.getElementById('deselectAllBiases');
if (deselectAllBiases) {
  deselectAllBiases.addEventListener('click', () => {
    document.querySelectorAll('.bias-item input[type="checkbox"]').forEach(cb => cb.checked = false);
  });
}

// Save Biases Selection
const saveBiasesBtn = document.getElementById('saveBiasesBtn');
if (saveBiasesBtn) {
  saveBiasesBtn.addEventListener('click', async () => {
    const selectedBiases = [];
    AVAILABLE_BIASES.forEach(bias => {
      const checkbox = document.getElementById(`bias_${bias.id}`);
      if (checkbox && checkbox.checked) selectedBiases.push(bias.id);
    });
    
    if (selectedBiases.length === 0) {
      alert('Please select at least one cognitive bias to detect.');
      return;
    }
    
    try {
      const currentSettings = await chrome.storage.sync.get(['analysisMode', 'customRuns', 'apiKey']);
      await chrome.storage.sync.set({
        analysisMode: currentSettings.analysisMode,
        customRuns: currentSettings.customRuns,
        selectedBiases
      });
      
      updateBiasCount(selectedBiases.length);
      const modal = document.getElementById('biasModal');
      if (modal) modal.style.display = 'none';
      
      const statusDiv = document.getElementById('settingsStatus');
      showStatus(statusDiv, `✓ ${selectedBiases.length} biases selected!`, 'success');
      
      // Update current status
      updateCurrentStatus({
        analysisMode: currentSettings.analysisMode,
        customRuns: currentSettings.customRuns,
        selectedBiases
      });
      
    } catch (error) {
      alert('Error saving bias selection: ' + error.message);
    }
  });
}

function showStatus(statusDiv, message, type) {
  statusDiv.textContent = message;
  statusDiv.className = 'status ' + type;
  
  if (type === 'success') {
    setTimeout(() => statusDiv.style.display = 'none', 3000);
  }
}
