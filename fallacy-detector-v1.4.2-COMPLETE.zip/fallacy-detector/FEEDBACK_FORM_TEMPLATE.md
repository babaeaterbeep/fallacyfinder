# Fallacy Detector Beta Feedback Form

## Copy this structure into Google Forms

---

### Section 1: About You

**1. What's your name? (Optional)**
- Short answer

**2. Email (if you want follow-up) (Optional)**
- Short answer

**3. How would you describe yourself?**
- [ ] Journalist
- [ ] Researcher
- [ ] Student
- [ ] Tech professional
- [ ] General news reader
- [ ] Media critic
- [ ] Other: ___________

**4. How often do you read news?**
- ( ) Multiple times per day
- ( ) Daily
- ( ) Few times per week
- ( ) Occasionally
- ( ) Rarely

---

### Section 2: Installation & Setup

**5. How easy was it to install the extension?**
- ( ) Very easy (1-5 minutes)
- ( ) Easy (5-10 minutes)
- ( ) Moderate (10-20 minutes)
- ( ) Difficult (20+ minutes)
- ( ) Could not install

**6. Did you encounter any installation issues?**
- ( ) No issues
- ( ) Minor issues (but figured it out)
- ( ) Major issues (needed help)
- ( ) Could not complete

**7. If you had issues, describe them:**
- Long answer

**8. Getting the API key was:**
- ( ) Easy
- ( ) Moderate
- ( ) Difficult
- ( ) Did not get API key

---

### Section 3: Usage & Testing

**9. How many articles did you analyze?**
- ( ) 1-5
- ( ) 6-10
- ( ) 11-20
- ( ) 21-50
- ( ) 50+

**10. What types of content did you test? (Check all that apply)**
- [ ] Mainstream news (CNN, BBC, NYT)
- [ ] Political commentary (left-leaning)
- [ ] Political commentary (right-leaning)
- [ ] Opinion pieces
- [ ] Scientific articles
- [ ] Local news
- [ ] International news
- [ ] Social media posts
- [ ] Other: ___________

**11. Which mode did you use most?**
- ( ) Fast mode (6 seconds)
- ( ) Accurate mode (17 seconds)
- ( ) Both equally
- ( ) Custom runs

**12. Did you try the "Run Accurate" button?**
- ( ) Yes, multiple times
- ( ) Yes, once or twice
- ( ) No, didn't notice it
- ( ) No, Fast was good enough

---

### Section 4: Accuracy & Results

**13. Did the bias scores seem accurate?**
- ( ) Very accurate
- ( ) Mostly accurate
- ( ) Sometimes accurate
- ( ) Rarely accurate
- ( ) Not accurate at all

**14. Give an example of a GOOD analysis:**
- Long answer
- (Include: website, article topic, score given, why it was good)

**15. Give an example of a BAD analysis (if any):**
- Long answer
- (Include: website, article topic, score given, what was wrong)

**16. Did Fast mode and Accurate mode give similar scores?**
- ( ) Yes, very similar (within 1 point)
- ( ) Mostly similar (within 2 points)
- ( ) Sometimes different (2-3 points)
- ( ) Often very different (3+ points)
- ( ) Didn't compare

**17. Were the fallacy explanations helpful?**
- ( ) Very helpful - clear and specific
- ( ) Somewhat helpful
- ( ) Not very helpful
- ( ) Didn't read them
- ( ) Not applicable (no fallacies found)

---

### Section 5: User Experience

**18. The interface was:**
- ( ) Very intuitive
- ( ) Mostly intuitive
- ( ) Somewhat confusing
- ( ) Very confusing

**19. The popup design was:**
- ( ) Professional and trustworthy
- ( ) Good, but could improve
- ( ) Acceptable
- ( ) Needs work

**20. The wait time for Fast mode (~6 seconds) was:**
- ( ) Perfect
- ( ) Acceptable
- ( ) A bit slow
- ( ) Too slow

**21. Did you understand the difference between Fast and Accurate modes?**
- ( ) Yes, very clear
- ( ) Mostly clear
- ( ) Somewhat unclear
- ( ) Confusing

**22. Did you use the bias configuration feature?**
- ( ) Yes, and it worked well
- ( ) Yes, but had issues
- ( ) No, didn't notice it
- ( ) No, didn't need it

**23. What did you like MOST about the extension?**
- Long answer

**24. What did you like LEAST about the extension?**
- Long answer

---

### Section 6: Bugs & Issues

**25. Did you encounter any bugs or errors?**
- ( ) No bugs
- ( ) Minor bugs (annoying but worked)
- ( ) Major bugs (couldn't use properly)
- ( ) Extension crashed

**26. Describe any bugs in detail:**
- Long answer

**27. Were there any websites where it didn't work well?**
- Long answer
- (Include specific URLs if possible)

---

### Section 7: Value & Usage

**28. Would you use this extension regularly?**
- ( ) Definitely yes
- ( ) Probably yes
- ( ) Maybe
- ( ) Probably not
- ( ) Definitely not

**29. Why or why not?**
- Long answer

**30. Would you pay for this as a subscription?**
- ( ) Yes, $5/month
- ( ) Yes, $3/month
- ( ) Yes, $1/month
- ( ) Maybe, depends on features
- ( ) No

**31. Would you recommend this to others?**
- ( ) Definitely
- ( ) Probably
- ( ) Maybe
- ( ) Probably not
- ( ) Definitely not

**32. Who would benefit most from this tool?**
- Long answer

---

### Section 8: Feature Requests

**33. What features are missing that you'd want?**
- Long answer

**34. Rate these potential features (1-5, 1=not useful, 5=very useful)**

[Matrix question with 1-5 scale for each:]
- Dark mode
- Browser action (analyze whole page automatically)
- History of analyses
- Export to CSV/PDF
- Share results link
- Browser extension for other browsers (Firefox, Safari)
- Mobile app
- Batch analysis (multiple articles)
- Custom bias definitions
- Comparison mode (compare two articles)
- API access
- Integration with social media

**35. Other feature ideas:**
- Long answer

---

### Section 9: Trust & Concerns

**36. Do you trust the AI-generated results?**
- ( ) Completely trust
- ( ) Mostly trust
- ( ) Somewhat trust
- ( ) Don't really trust
- ( ) Don't trust at all

**37. What concerns do you have about the tool? (Check all that apply)**
- [ ] AI might be biased itself
- [ ] Privacy concerns
- [ ] Cost of API usage
- [ ] Accuracy of results
- [ ] Relying too much on AI
- [ ] Misuse potential
- [ ] Other: ___________

**38. Would you trust this more if:**
- [ ] It showed confidence scores (it does - did you notice?)
- [ ] It showed multiple analyses
- [ ] It explained its reasoning more
- [ ] It was validated by experts
- [ ] It was open source
- [ ] Other: ___________

---

### Section 10: Final Thoughts

**39. Overall rating (1-5 stars):**
- ( ) ⭐ (1 star)
- ( ) ⭐⭐ (2 stars)
- ( ) ⭐⭐⭐ (3 stars)
- ( ) ⭐⭐⭐⭐ (4 stars)
- ( ) ⭐⭐⭐⭐⭐ (5 stars)

**40. Any other comments, suggestions, or feedback?**
- Long answer

**41. Can we contact you for follow-up questions?**
- ( ) Yes, use email provided above
- ( ) No, please keep anonymous

**42. Would you be interested in being an early advocate/beta tester for future updates?**
- ( ) Yes, definitely!
- ( ) Maybe
- ( ) No thanks

---

## Thank you for your feedback! 🧠

Your input helps make Fallacy Detector better for everyone.

**Questions?** Contact: [your-email]

---

**Estimated time to complete:** 10-15 minutes
